export type TabType = 'catatan' | 'quran' | 'belajar';

export type CatatanSubTab = 'hari-ini' | 'habit' | 'jurnal' | 'target';

export type MoodType = 'senang' | 'baik' | 'biasa' | 'sedih' | 'lelah';

export interface UserProfile {
  name: string;
  callSign: string; // 'Ukhti' | 'Bunda' | 'Sahabat' | dll.
  avatarIcon: string; // '🌷' | '🌸' | '🌿' | '🌹' | '✨' | '🕊️'
  bio: string;
  dailyNiat: string;
  tilawahDailyTarget: number;
}

export interface DailyTask {
  id: string;
  text: string;
  completed: boolean;
  category?: string;
}

export interface DailyReflection {
  halBaik: string;
  perbaikanBesok: string;
  updatedAt?: string;
}

export interface DailyGratitude {
  text: string;
  updatedAt?: string;
}

export interface ShalatTracker {
  subuh: boolean;
  dzuhur: boolean;
  ashar: boolean;
  maghrib: boolean;
  isya: boolean;
}

export interface TilawahTracker {
  pagesRead: number;
  dailyGoal: number;
  surahNote?: string;
}

export interface DzikirTracker {
  pagi: boolean;
  petang: boolean;
  counterPagi: number;
  counterPetang: number;
}

export interface KebaikanTracker {
  done: boolean;
  note: string;
}

export interface HabitItem {
  id: string;
  name: string;
  frequency: string; // 'Setiap Hari' | 'Hari Kerja' | 'Akhir Pekan'
  category: 'ibadah' | 'kesehatan' | 'mindset' | 'rutinitas';
  streak: number;
  completedToday: boolean;
  last7Days: boolean[];
}

export interface JournalEntry {
  id: string;
  title: string;
  content: string;
  mood: MoodType;
  date: string;
  createdAt: number;
}

export type TargetCategory = 'personal' | 'ibadah' | 'productivity';

export interface TargetItem {
  id: string;
  name: string;
  category: TargetCategory;
  progress: number; // 0 - 100
  deadline: string;
  status: 'ongoing' | 'completed';
  notes?: string;
}

export interface WeeklySummaryData {
  shalatCompleted: number;
  shalatTotal: number;
  tilawahPages: number;
  habitPercentage: number;
  journalDays: number;
  kebaikanCount: number;
}

export interface RuqunPamphlet {
  id: string;
  title: string;
  subtitle: string;
  fileName: string;
  altFileName?: string;
  tag: string;
}
