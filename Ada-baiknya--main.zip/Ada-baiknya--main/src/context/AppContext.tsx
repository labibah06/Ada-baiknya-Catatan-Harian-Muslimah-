import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  TabType,
  CatatanSubTab,
  MoodType,
  UserProfile,
  DailyTask,
  DailyReflection,
  DailyGratitude,
  ShalatTracker,
  TilawahTracker,
  DzikirTracker,
  KebaikanTracker,
  HabitItem,
  JournalEntry,
  TargetItem,
  WeeklySummaryData,
} from '../types';

interface ToastMessage {
  id: string;
  message: string;
  type?: 'success' | 'info';
}

interface AppContextType {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  catatanSubTab: CatatanSubTab;
  setCatatanSubTab: (subTab: CatatanSubTab) => void;
  ruqunDetailOpen: boolean;
  setRuqunDetailOpen: (open: boolean) => void;
  profile: UserProfile;
  updateProfile: (updates: Partial<UserProfile>) => void;
  isProfileModalOpen: boolean;
  setIsProfileModalOpen: (open: boolean) => void;
  tasks: DailyTask[];
  toggleTask: (id: string) => void;
  reflection: DailyReflection;
  saveReflection: (reflection: { halBaik: string; perbaikanBesok: string }) => void;
  reflectionSavedStatus: boolean;
  gratitude: DailyGratitude;
  saveGratitude: (text: string) => void;
  gratitudeSavedStatus: boolean;
  mood: MoodType | null;
  setMood: (mood: MoodType) => void;
  shalat: ShalatTracker;
  toggleShalat: (prayer: keyof ShalatTracker) => void;
  tilawah: TilawahTracker;
  updateTilawahPages: (pages: number) => void;
  updateTilawahGoal: (goal: number) => void;
  dzikir: DzikirTracker;
  toggleDzikir: (type: 'pagi' | 'petang') => void;
  incrementDzikirCounter: (type: 'pagi' | 'petang') => void;
  resetDzikirCounter: (type: 'pagi' | 'petang') => void;
  kebaikan: KebaikanTracker;
  toggleKebaikan: (done: boolean) => void;
  updateKebaikanNote: (note: string) => void;
  habits: HabitItem[];
  toggleHabit: (id: string) => void;
  addHabit: (habit: Omit<HabitItem, 'id' | 'streak' | 'completedToday' | 'last7Days'>) => void;
  deleteHabit: (id: string) => void;
  journals: JournalEntry[];
  addJournal: (entry: Omit<JournalEntry, 'id' | 'createdAt'>) => void;
  updateJournal: (id: string, entry: Partial<Omit<JournalEntry, 'id' | 'createdAt'>>) => void;
  deleteJournal: (id: string) => void;
  targets: TargetItem[];
  addTarget: (target: Omit<TargetItem, 'id'>) => void;
  updateTarget: (id: string, updates: Partial<Omit<TargetItem, 'id'>>) => void;
  deleteTarget: (id: string) => void;
  weeklySummary: WeeklySummaryData;
  toasts: ToastMessage[];
  showToast: (message: string) => void;
}

const STORAGE_KEYS = {
  TASKS: 'ada_baiknya_tasks_v1',
  REFLECTION: 'ada_baiknya_reflection_v1',
  GRATITUDE: 'ada_baiknya_gratitude_v1',
  MOOD: 'ada_baiknya_mood_v1',
  SHALAT: 'ada_baiknya_shalat_v1',
  TILAWAH: 'ada_baiknya_tilawah_v1',
  DZIKIR: 'ada_baiknya_dzikir_v1',
  KEBAIKAN: 'ada_baiknya_kebaikan_v1',
  HABITS: 'ada_baiknya_habits_v1',
  JOURNALS: 'ada_baiknya_journals_v1',
  TARGETS: 'ada_baiknya_targets_v1',
  PROFILE: 'ada_baiknya_profile_v1',
};

const initialProfile: UserProfile = {
  name: 'Fathimah',
  callSign: 'Ukhti',
  avatarIcon: '🌷',
  bio: 'Muslimah yang sedang berproses menjadi lebih baik, sedikit demi sedikit.',
  dailyNiat: 'Bismillah, melangkah dengan tenang dan mengharap ridha-Nya.',
  tilawahDailyTarget: 2,
};

const initialTasks: DailyTask[] = [
  { id: '1', text: 'Shalat tepat waktu', completed: false },
  { id: '2', text: 'Tilawah 2 halaman', completed: true },
  { id: '3', text: 'Dzikir pagi', completed: true },
  { id: '4', text: 'Dzikir petang', completed: false },
  { id: '5', text: 'Berbuat baik kepada keluarga', completed: true },
  { id: '6', text: 'Luangkan 10 menit untuk diri sendiri', completed: false },
];

const initialHabits: HabitItem[] = [
  {
    id: 'h1',
    name: 'Bangun lebih awal',
    frequency: 'Setiap Hari',
    category: 'rutinitas',
    streak: 5,
    completedToday: true,
    last7Days: [true, true, true, false, true, true, true],
  },
  {
    id: 'h2',
    name: 'Minum air cukup (8 gelas)',
    frequency: 'Setiap Hari',
    category: 'kesehatan',
    streak: 3,
    completedToday: true,
    last7Days: [false, true, true, true, true, true, true],
  },
  {
    id: 'h3',
    name: 'Membaca Qur’an',
    frequency: 'Setiap Hari',
    category: 'ibadah',
    streak: 8,
    completedToday: true,
    last7Days: [true, true, true, true, true, true, true],
  },
  {
    id: 'h4',
    name: 'Kurangi scrolling',
    frequency: 'Setiap Hari',
    category: 'mindset',
    streak: 2,
    completedToday: false,
    last7Days: [true, false, true, true, false, true, false],
  },
  {
    id: 'h5',
    name: 'Membaca buku inspiratif',
    frequency: 'Hari Kerja',
    category: 'mindset',
    streak: 4,
    completedToday: false,
    last7Days: [true, true, false, true, true, false, false],
  },
  {
    id: 'h6',
    name: 'Olahraga ringan / stretching',
    frequency: 'Setiap Hari',
    category: 'kesehatan',
    streak: 1,
    completedToday: false,
    last7Days: [false, true, false, false, true, false, false],
  },
  {
    id: 'h7',
    name: 'Tidur lebih teratur',
    frequency: 'Setiap Hari',
    category: 'kesehatan',
    streak: 6,
    completedToday: false,
    last7Days: [true, true, true, true, true, true, false],
  },
  {
    id: 'h8',
    name: 'Merapikan kamar',
    frequency: 'Setiap Hari',
    category: 'rutinitas',
    streak: 7,
    completedToday: true,
    last7Days: [true, true, true, true, true, true, true],
  },
];

const initialJournals: JournalEntry[] = [
  {
    id: 'j1',
    title: 'Mencari Ketenangan di Sela Kesibukan',
    content:
      'Hari ini terasa cukup padat, tetapi ada jeda 15 menit sehabis shalat di mana aku bisa duduk tenang, menarik napas dalam, dan bersyukur. Ternyata rasa damai itu tidak harus menunggu semua urusan tuntas sempurna. Cukup hadir sepenuhnya di detik ini.',
    mood: 'senang',
    date: 'Jumat, 2 Oktober 2026',
    createdAt: Date.now() - 3600000 * 4,
  },
  {
    id: 'j2',
    title: 'Belajar Menerima Diri & Berlapang Dada',
    content:
      'Terkadang ada ekspektasi yang belum terwujud sesuai rencana. Dulu aku sering menyalahkan diri sendiri, tapi pelan-pelan aku belajar: satu langkah kecil tetap berarti. Yang penting niatnya baik dan terus bertumbuh.',
    mood: 'baik',
    date: 'Kamis, 1 Oktober 2026',
    createdAt: Date.now() - 3600000 * 28,
  },
];

const initialTargets: TargetItem[] = [
  {
    id: 't1',
    name: 'Tilawah 2 halaman setiap hari',
    category: 'ibadah',
    progress: 75,
    deadline: 'Akhir Oktober 2026',
    status: 'ongoing',
    notes: 'Konsisten membaca selepas Subuh atau Maghrib',
  },
  {
    id: 't2',
    name: 'Lebih rutin membaca 15 menit',
    category: 'personal',
    progress: 60,
    deadline: '20 Oktober 2026',
    status: 'ongoing',
    notes: 'Buku pengembangan diri & kisah inspiratif',
  },
  {
    id: 't3',
    name: 'Belajar skill baru desain Canva & visual',
    category: 'productivity',
    progress: 45,
    deadline: '30 Oktober 2026',
    status: 'ongoing',
    notes: 'Untuk menunjang tugas dan materi kajian',
  },
  {
    id: 't4',
    name: 'Shalat Dhuha minimal 3x sepekan',
    category: 'ibadah',
    progress: 85,
    deadline: 'Akhir Pekan Ini',
    status: 'ongoing',
    notes: '2 rakaat di pagi hari sebelum mulai beraktivitas',
  },
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<TabType>('catatan');
  const [catatanSubTab, setCatatanSubTab] = useState<CatatanSubTab>('hari-ini');
  const [ruqunDetailOpen, setRuqunDetailOpen] = useState<boolean>(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // 0. User Profile
  const [profile, setProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return saved ? JSON.parse(saved) : initialProfile;
    } catch {
      return initialProfile;
    }
  });

  const updateProfile = (updates: Partial<UserProfile>) => {
    setProfile((prev) => {
      const updated = { ...prev, ...updates };
      try {
        localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(updated));
      } catch (e) {
        console.warn(e);
      }
      return updated;
    });
    showToast('Profil & preferensi tersimpan 🌸');
  };

  // Show a gentle toast
  const showToast = (message: string) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3000);
  };

  // 1. Daily Tasks
  const [tasks, setTasks] = useState<DailyTask[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.TASKS);
      return saved ? JSON.parse(saved) : initialTasks;
    } catch {
      return initialTasks;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
    } catch (e) {
      console.warn(e);
    }
  }, [tasks]);

  const toggleTask = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t))
    );
  };

  // 2. Reflection
  const [reflection, setReflectionState] = useState<DailyReflection>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.REFLECTION);
      return saved
        ? JSON.parse(saved)
        : {
            halBaik: 'Menyempatkan tilawah dengan tenang dan sarapan sehat bersama keluarga.',
            perbaikanBesok: 'Membatasi waktu menatap layar sebelum tidur.',
          };
    } catch {
      return { halBaik: '', perbaikanBesok: '' };
    }
  });
  const [reflectionSavedStatus, setReflectionSavedStatus] = useState<boolean>(false);

  const saveReflection = ({
    halBaik,
    perbaikanBesok,
  }: {
    halBaik: string;
    perbaikanBesok: string;
  }) => {
    const updated: DailyReflection = {
      halBaik,
      perbaikanBesok,
      updatedAt: new Date().toISOString(),
    };
    setReflectionState(updated);
    try {
      localStorage.setItem(STORAGE_KEYS.REFLECTION, JSON.stringify(updated));
    } catch (e) {
      console.warn(e);
    }
    setReflectionSavedStatus(true);
    showToast('Refleksimu tersimpan 💗');
    setTimeout(() => setReflectionSavedStatus(false), 3500);
  };

  // 3. Gratitude
  const [gratitude, setGratitudeState] = useState<DailyGratitude>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.GRATITUDE);
      return saved
        ? JSON.parse(saved)
        : {
            text: 'Tubuh yang masih sehat, udara pagi yang segar, dan hati yang diberi kelembutan untuk terus belajar.',
          };
    } catch {
      return { text: '' };
    }
  });
  const [gratitudeSavedStatus, setGratitudeSavedStatus] = useState<boolean>(false);

  const saveGratitude = (text: string) => {
    const updated: DailyGratitude = {
      text,
      updatedAt: new Date().toISOString(),
    };
    setGratitudeState(updated);
    try {
      localStorage.setItem(STORAGE_KEYS.GRATITUDE, JSON.stringify(updated));
    } catch (e) {
      console.warn(e);
    }
    setGratitudeSavedStatus(true);
    showToast('Rasa syukurmu tercatat 🌸');
    setTimeout(() => setGratitudeSavedStatus(false), 3500);
  };

  // 4. Mood
  const [mood, setMoodState] = useState<MoodType | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.MOOD);
      return (saved as MoodType) || 'senang';
    } catch {
      return 'senang';
    }
  });

  const setMood = (newMood: MoodType) => {
    setMoodState(newMood);
    try {
      localStorage.setItem(STORAGE_KEYS.MOOD, newMood);
    } catch (e) {
      console.warn(e);
    }
    showToast('Mood hari ini tercatat ✨');
  };

  // 5. Shalat
  const [shalat, setShalat] = useState<ShalatTracker>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SHALAT);
      return saved
        ? JSON.parse(saved)
        : {
            subuh: true,
            dzuhur: true,
            ashar: true,
            maghrib: false,
            isya: false,
          };
    } catch {
      return {
        subuh: false,
        dzuhur: false,
        ashar: false,
        maghrib: false,
        isya: false,
      };
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SHALAT, JSON.stringify(shalat));
    } catch (e) {
      console.warn(e);
    }
  }, [shalat]);

  const toggleShalat = (prayer: keyof ShalatTracker) => {
    setShalat((prev) => ({
      ...prev,
      [prayer]: !prev[prayer],
    }));
  };

  // 6. Tilawah
  const [tilawah, setTilawah] = useState<TilawahTracker>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.TILAWAH);
      return saved
        ? JSON.parse(saved)
        : {
            pagesRead: 2,
            dailyGoal: 2,
            surahNote: 'Surah Maryam',
          };
    } catch {
      return { pagesRead: 0, dailyGoal: 2 };
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.TILAWAH, JSON.stringify(tilawah));
    } catch (e) {
      console.warn(e);
    }
  }, [tilawah]);

  const updateTilawahPages = (pages: number) => {
    const val = Math.max(0, pages);
    setTilawah((prev) => ({ ...prev, pagesRead: val }));
  };

  const updateTilawahGoal = (goal: number) => {
    const val = Math.max(1, goal);
    setTilawah((prev) => ({ ...prev, dailyGoal: val }));
  };

  // 7. Dzikir
  const [dzikir, setDzikir] = useState<DzikirTracker>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DZIKIR);
      return saved
        ? JSON.parse(saved)
        : {
            pagi: true,
            petang: false,
            counterPagi: 33,
            counterPetang: 0,
          };
    } catch {
      return { pagi: false, petang: false, counterPagi: 0, counterPetang: 0 };
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.DZIKIR, JSON.stringify(dzikir));
    } catch (e) {
      console.warn(e);
    }
  }, [dzikir]);

  const toggleDzikir = (type: 'pagi' | 'petang') => {
    setDzikir((prev) => ({
      ...prev,
      [type]: !prev[type],
    }));
  };

  const incrementDzikirCounter = (type: 'pagi' | 'petang') => {
    setDzikir((prev) => {
      const key = type === 'pagi' ? 'counterPagi' : 'counterPetang';
      const newVal = prev[key] + 1;
      return {
        ...prev,
        [key]: newVal,
        [type]: newVal >= 33 ? true : prev[type],
      };
    });
  };

  const resetDzikirCounter = (type: 'pagi' | 'petang') => {
    setDzikir((prev) => ({
      ...prev,
      [type === 'pagi' ? 'counterPagi' : 'counterPetang']: 0,
    }));
  };

  // 8. Kebaikan
  const [kebaikan, setKebaikan] = useState<KebaikanTracker>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.KEBAIKAN);
      return saved
        ? JSON.parse(saved)
        : {
            done: true,
            note: 'Membantu ibu menyiapkan makanan dan tersenyum tulus kepada tetangga',
          };
    } catch {
      return { done: false, note: '' };
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.KEBAIKAN, JSON.stringify(kebaikan));
    } catch (e) {
      console.warn(e);
    }
  }, [kebaikan]);

  const toggleKebaikan = (done: boolean) => {
    setKebaikan((prev) => ({ ...prev, done }));
  };

  const updateKebaikanNote = (note: string) => {
    setKebaikan((prev) => ({ ...prev, note }));
  };

  // 9. Habits
  const [habits, setHabits] = useState<HabitItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.HABITS);
      return saved ? JSON.parse(saved) : initialHabits;
    } catch {
      return initialHabits;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.HABITS, JSON.stringify(habits));
    } catch (e) {
      console.warn(e);
    }
  }, [habits]);

  const toggleHabit = (id: string) => {
    setHabits((prev) =>
      prev.map((h) => {
        if (h.id === id) {
          const nextCompleted = !h.completedToday;
          const nextStreak = nextCompleted ? h.streak + 1 : Math.max(0, h.streak - 1);
          const nextLast7 = [...h.last7Days.slice(0, 6), nextCompleted];
          return {
            ...h,
            completedToday: nextCompleted,
            streak: nextStreak,
            last7Days: nextLast7,
          };
        }
        return h;
      })
    );
  };

  const addHabit = (habitData: Omit<HabitItem, 'id' | 'streak' | 'completedToday' | 'last7Days'>) => {
    const newHabit: HabitItem = {
      ...habitData,
      id: 'h_' + Date.now(),
      streak: 0,
      completedToday: false,
      last7Days: [false, false, false, false, false, false, false],
    };
    setHabits((prev) => [newHabit, ...prev]);
    showToast('Habit baru berhasil ditambahkan 🌱');
  };

  const deleteHabit = (id: string) => {
    setHabits((prev) => prev.filter((h) => h.id !== id));
    showToast('Habit dihapus');
  };

  // 10. Journals
  const [journals, setJournals] = useState<JournalEntry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.JOURNALS);
      return saved ? JSON.parse(saved) : initialJournals;
    } catch {
      return initialJournals;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.JOURNALS, JSON.stringify(journals));
    } catch (e) {
      console.warn(e);
    }
  }, [journals]);

  const addJournal = (entryData: Omit<JournalEntry, 'id' | 'createdAt'>) => {
    const newEntry: JournalEntry = {
      ...entryData,
      id: 'j_' + Date.now(),
      createdAt: Date.now(),
    };
    setJournals((prev) => [newEntry, ...prev]);
    showToast('Jurnal berhasil disimpan 📖');
  };

  const updateJournal = (id: string, updates: Partial<Omit<JournalEntry, 'id' | 'createdAt'>>) => {
    setJournals((prev) =>
      prev.map((j) => (j.id === id ? { ...j, ...updates } : j))
    );
    showToast('Jurnal diperbarui 🌸');
  };

  const deleteJournal = (id: string) => {
    setJournals((prev) => prev.filter((j) => j.id !== id));
    showToast('Jurnal dihapus');
  };

  // 11. Targets
  const [targets, setTargets] = useState<TargetItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.TARGETS);
      return saved ? JSON.parse(saved) : initialTargets;
    } catch {
      return initialTargets;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.TARGETS, JSON.stringify(targets));
    } catch (e) {
      console.warn(e);
    }
  }, [targets]);

  const addTarget = (targetData: Omit<TargetItem, 'id'>) => {
    const newTarget: TargetItem = {
      ...targetData,
      id: 't_' + Date.now(),
    };
    setTargets((prev) => [newTarget, ...prev]);
    showToast('Target baru ditambahkan 🎯');
  };

  const updateTarget = (id: string, updates: Partial<Omit<TargetItem, 'id'>>) => {
    setTargets((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          const updated = { ...t, ...updates };
          if (updated.progress >= 100) {
            updated.status = 'completed';
          }
          return updated;
        }
        return t;
      })
    );
    showToast('Target diperbarui ✨');
  };

  const deleteTarget = (id: string) => {
    setTargets((prev) => prev.filter((t) => t.id !== id));
    showToast('Target dihapus');
  };

  // 12. Weekly Summary Data (computed + realistic baseline)
  const completedHabitsToday = habits.filter((h) => h.completedToday).length;
  const habitPercentage = Math.round(
    habits.length > 0 ? (completedHabitsToday / habits.length) * 100 : 76
  );

  const weeklySummary: WeeklySummaryData = {
    shalatCompleted: 34,
    shalatTotal: 35,
    tilawahPages: 42 + tilawah.pagesRead,
    habitPercentage: Math.max(habitPercentage, 76),
    journalDays: Math.min(7, journals.length + 3),
    kebaikanCount: 12 + (kebaikan.done ? 1 : 0),
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        catatanSubTab,
        setCatatanSubTab,
        ruqunDetailOpen,
        setRuqunDetailOpen,
        profile,
        updateProfile,
        isProfileModalOpen,
        setIsProfileModalOpen,
        tasks,
        toggleTask,
        reflection,
        saveReflection,
        reflectionSavedStatus,
        gratitude,
        saveGratitude,
        gratitudeSavedStatus,
        mood,
        setMood,
        shalat,
        toggleShalat,
        tilawah,
        updateTilawahPages,
        updateTilawahGoal,
        dzikir,
        toggleDzikir,
        incrementDzikirCounter,
        resetDzikirCounter,
        kebaikan,
        toggleKebaikan,
        updateKebaikanNote,
        habits,
        toggleHabit,
        addHabit,
        deleteHabit,
        journals,
        addJournal,
        updateJournal,
        deleteJournal,
        targets,
        addTarget,
        updateTarget,
        deleteTarget,
        weeklySummary,
        toasts,
        showToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
