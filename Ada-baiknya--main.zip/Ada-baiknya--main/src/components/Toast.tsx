import React from 'react';
import { useApp } from '../context/AppContext';

export const ToastContainer: React.FC = () => {
  const { toasts } = useApp();

  if (toasts.length === 0) return null;

  return (
    <div
      aria-live="polite"
      className="fixed top-14 left-0 right-0 z-50 pointer-events-none flex flex-col items-center px-4 space-y-2"
    >
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="pointer-events-auto bg-[#2C2B2A] text-[#FAF7F2] text-xs font-medium px-4 py-2.5 rounded-2xl shadow-lg border border-white/10 animate-in fade-in slide-in-from-top-2 duration-200 flex items-center gap-2 max-w-sm"
        >
          <span>{toast.message}</span>
        </div>
      ))}
    </div>
  );
};
