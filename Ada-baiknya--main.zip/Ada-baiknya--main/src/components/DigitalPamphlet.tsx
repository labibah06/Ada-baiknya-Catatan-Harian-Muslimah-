import React from 'react';
import {
  Check,
  X,
  Sparkles,
  Star,
  BookOpen,
  Calendar,
  Users,
  Video,
  Award,
  Heart,
  TrendingUp,
  ShieldCheck,
} from 'lucide-react';

interface DigitalPamphletProps {
  id: string;
}

export const DigitalPamphlet: React.FC<DigitalPamphletProps> = ({ id }) => {
  // PAMFLET 1: Perubahan Nyata Setelah Belajar Al-Qur'an
  if (id === 'pamflet-1') {
    return (
      <div className="bg-gradient-to-b from-[#FFF0F3] via-[#FFE5EC] to-[#FFF5F7] p-4 sm:p-5 rounded-2xl border border-[#FAD2E1] text-[#2C2B2A] select-none text-left">
        {/* RuQun Logo Header */}
        <div className="text-center mb-3">
          <div className="inline-flex items-center justify-center gap-1.5 px-3 py-1 rounded-full bg-white/90 border border-[#FAD2E1] text-[#C44D68] text-xs font-semibold shadow-xs">
            <span className="text-sm">🌸</span>
            <span>Rumah Qur'an Nur Hidayah</span>
          </div>
          <h3 className="text-base sm:text-lg font-extrabold text-[#991B3A] mt-2 leading-snug">
            Perubahan Nyata Setelah Belajar Al-Qur'an
          </h3>
          <p className="text-[11px] text-[#803348] font-medium">
            Bimbingan Ustazah Berpengalaman, Metode Terstruktur & Penuh Kasih
          </p>
        </div>

        {/* Before vs After Columns */}
        <div className="grid grid-cols-2 gap-2 sm:gap-3 my-3">
          {/* Sebelum Belajar */}
          <div className="bg-white/95 rounded-2xl p-3 border border-[#F8B4C8] shadow-xs flex flex-col justify-between">
            <div>
              <span className="inline-block px-2 py-0.5 rounded-full bg-[#E63946] text-white text-[10px] font-bold mb-1.5">
                Sebelum Belajar
              </span>
              <p className="text-[10px] text-[#4A4541] font-semibold leading-tight mb-2">
                Membaca Al-Qur'an Terasa Sulit & Membingungkan
              </p>
              <div className="space-y-1.5 text-[10px] text-[#554E48]">
                <div className="flex items-start gap-1 text-[#E63946]">
                  <X size={12} className="shrink-0 mt-0.5" />
                  <span className="text-[#4A4541]">Bacaan belum lancar</span>
                </div>
                <div className="flex items-start gap-1 text-[#E63946]">
                  <X size={12} className="shrink-0 mt-0.5" />
                  <span className="text-[#4A4541]">Masih banyak salah tajwid</span>
                </div>
                <div className="flex items-start gap-1 text-[#E63946]">
                  <X size={12} className="shrink-0 mt-0.5" />
                  <span className="text-[#4A4541]">Belum mengerti makhraj huruf</span>
                </div>
                <div className="flex items-start gap-1 text-[#E63946]">
                  <X size={12} className="shrink-0 mt-0.5" />
                  <span className="text-[#4A4541]">Belum percaya diri saat membaca</span>
                </div>
                <div className="flex items-start gap-1 text-[#E63946]">
                  <X size={12} className="shrink-0 mt-0.5" />
                  <span className="text-[#4A4541]">Hafalan belum terarah</span>
                </div>
              </div>
            </div>

            <div className="mt-3 pt-2 border-t border-[#F8D7DA]">
              <div className="flex justify-between text-[10px] font-bold mb-1">
                <span>Progress:</span>
                <span className="text-[#E63946]">20%</span>
              </div>
              <div className="w-full bg-[#FCECE9] h-2 rounded-full overflow-hidden">
                <div className="bg-[#E63946] h-full w-[20%]" />
              </div>
            </div>
          </div>

          {/* Setelah Belajar */}
          <div className="bg-white/95 rounded-2xl p-3 border border-[#B7E4C7] shadow-xs flex flex-col justify-between">
            <div>
              <span className="inline-block px-2 py-0.5 rounded-full bg-[#2A9D8F] text-white text-[10px] font-bold mb-1.5">
                Setelah Belajar
              </span>
              <p className="text-[10px] text-[#4A4541] font-semibold leading-tight mb-2">
                Membaca Al-Qur'an Jadi Mudah & Menyenangkan
              </p>
              <div className="space-y-1.5 text-[10px] text-[#554E48]">
                <div className="flex items-start gap-1 text-[#2A9D8F]">
                  <Check size={12} strokeWidth={3} className="shrink-0 mt-0.5" />
                  <span className="text-[#4A4541]">Bacaan lancar sesuai tajwid</span>
                </div>
                <div className="flex items-start gap-1 text-[#2A9D8F]">
                  <Check size={12} strokeWidth={3} className="shrink-0 mt-0.5" />
                  <span className="text-[#4A4541]">Makhraj huruf jelas & benar</span>
                </div>
                <div className="flex items-start gap-1 text-[#2A9D8F]">
                  <Check size={12} strokeWidth={3} className="shrink-0 mt-0.5" />
                  <span className="text-[#4A4541]">Hafalan lebih mudah & terarah</span>
                </div>
                <div className="flex items-start gap-1 text-[#2A9D8F]">
                  <Check size={12} strokeWidth={3} className="shrink-0 mt-0.5" />
                  <span className="text-[#4A4541]">Lebih percaya diri saat membaca</span>
                </div>
                <div className="flex items-start gap-1 text-[#2A9D8F]">
                  <Check size={12} strokeWidth={3} className="shrink-0 mt-0.5" />
                  <span className="text-[#4A4541]">Mencintai Al-Qur'an setiap hari</span>
                </div>
              </div>
            </div>

            <div className="mt-3 pt-2 border-t border-[#D8F3DC]">
              <div className="flex justify-between text-[10px] font-bold mb-1">
                <span>Progress:</span>
                <span className="text-[#2A9D8F]">90% ✨</span>
              </div>
              <div className="w-full bg-[#E8F5E9] h-2 rounded-full overflow-hidden">
                <div className="bg-[#2A9D8F] h-full w-[90%]" />
              </div>
            </div>
          </div>
        </div>

        {/* Quotes */}
        <div className="p-2.5 rounded-xl bg-white/80 border border-[#F8B4C8] text-[10px] text-[#803348] text-center italic mb-3">
          “Tidak apa-apa jika kamu belum bisa, semua bisa dimulai dari langkah kecil. Konsistensi hari ini adalah keberkahan di masa depan.”
        </div>

        {/* Feature Icons Row */}
        <div className="grid grid-cols-5 gap-1 text-center pt-1">
          <div className="p-1 rounded-lg bg-white/70">
            <span className="text-xs block">📖</span>
            <span className="text-[9px] font-semibold text-[#803348] block leading-tight">Metode Terstruktur</span>
          </div>
          <div className="p-1 rounded-lg bg-white/70">
            <span className="text-xs block">🎧</span>
            <span className="text-[9px] font-semibold text-[#803348] block leading-tight">Bimbingan Personal</span>
          </div>
          <div className="p-1 rounded-lg bg-white/70">
            <span className="text-xs block">📋</span>
            <span className="text-[9px] font-semibold text-[#803348] block leading-tight">Evaluasi Rutin</span>
          </div>
          <div className="p-1 rounded-lg bg-white/70">
            <span className="text-xs block">🤍</span>
            <span className="text-[9px] font-semibold text-[#803348] block leading-tight">Suasana Nyaman</span>
          </div>
          <div className="p-1 rounded-lg bg-white/70">
            <span className="text-xs block">📅</span>
            <span className="text-[9px] font-semibold text-[#803348] block leading-tight">Jadwal Fleksibel</span>
          </div>
        </div>
      </div>
    );
  }

  // PAMFLET 2: Kelas Privat Al-Qur'an (1 on 1)
  if (id === 'pamflet-2') {
    return (
      <div className="bg-gradient-to-b from-[#FFF5F2] via-[#FFEBE5] to-[#FFF0EC] p-4 sm:p-5 rounded-2xl border border-[#F5C7B8] text-[#2C2B2A] select-none text-left">
        <div className="text-center mb-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/90 border border-[#F5C7B8] text-[#C44D68] text-xs font-semibold shadow-xs">
            <span>🌸 RuQun · Kelas Online</span>
          </div>
          <h3 className="text-lg sm:text-xl font-extrabold text-[#D04860] mt-2 leading-tight">
            Kelas Privat Al-Qur'an
          </h3>
          <span className="inline-block px-3 py-1 rounded-full bg-[#D04860] text-white text-[11px] font-bold mt-1 shadow-xs">
            Belajar 1 on 1, Lebih Fokus & Terarah
          </span>
          <p className="text-[11px] text-[#6E4E45] mt-2 leading-relaxed">
            Dibimbing ustazah berpengalaman secara pribadi sesuai kebutuhanmu, agar belajar Al-Qur'an jadi lebih mudah, nyaman, dan berkah.
          </p>
        </div>

        {/* Keunggulan 5 Kartu */}
        <div className="space-y-1.5 my-3">
          <div className="flex items-center gap-2.5 p-2 rounded-xl bg-white/90 border border-[#F5C7B8]">
            <span className="w-6 h-6 rounded-lg bg-[#FFE3DC] text-[#D04860] flex items-center justify-center text-xs font-bold shrink-0">1</span>
            <div className="text-left">
              <strong className="text-[11px] text-[#2C2B2A] block leading-tight">1 Santri 1 Ustazah</strong>
              <span className="text-[10px] text-[#6E4E45]">Fokus penuh sesuai kebutuhan dan kecepatan belajarmu</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 p-2 rounded-xl bg-white/90 border border-[#F5C7B8]">
            <span className="w-6 h-6 rounded-lg bg-[#FFE3DC] text-[#D04860] flex items-center justify-center text-xs font-bold shrink-0">2</span>
            <div className="text-left">
              <strong className="text-[11px] text-[#2C2B2A] block leading-tight">Materi Personal</strong>
              <span className="text-[10px] text-[#6E4E45]">Disesuaikan dengan level kemampuan dan target hafalanmu</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 p-2 rounded-xl bg-white/90 border border-[#F5C7B8]">
            <span className="w-6 h-6 rounded-lg bg-[#FFE3DC] text-[#D04860] flex items-center justify-center text-xs font-bold shrink-0">3</span>
            <div className="text-left">
              <strong className="text-[11px] text-[#2C2B2A] block leading-tight">Waktu Fleksibel</strong>
              <span className="text-[10px] text-[#6E4E45]">Bebas pilih jadwal belajar yang pas dengan rutinitasmu</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 p-2 rounded-xl bg-white/90 border border-[#F5C7B8]">
            <span className="w-6 h-6 rounded-lg bg-[#FFE3DC] text-[#D04860] flex items-center justify-center text-xs font-bold shrink-0">4</span>
            <div className="text-left">
              <strong className="text-[11px] text-[#2C2B2A] block leading-tight">Evaluasi Rutin</strong>
              <span className="text-[10px] text-[#6E4E45]">Pantau perkembangan bacaan dan hafalan secara berkala</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 p-2 rounded-xl bg-white/90 border border-[#F5C7B8]">
            <span className="w-6 h-6 rounded-lg bg-[#FFE3DC] text-[#D04860] flex items-center justify-center text-xs font-bold shrink-0">5</span>
            <div className="text-left">
              <strong className="text-[11px] text-[#2C2B2A] block leading-tight">Suasana Nyaman</strong>
              <span className="text-[10px] text-[#6E4E45]">Belajar online dari rumah dengan suasana yang tenang dan suportif</span>
            </div>
          </div>
        </div>

        {/* Kelas yang Tersedia */}
        <div className="mt-3 p-3 bg-white/95 rounded-2xl border border-[#F5C7B8] text-center">
          <span className="text-[10px] font-bold text-[#803348] uppercase tracking-wider block mb-2">
            Kelas yang Tersedia
          </span>
          <div className="grid grid-cols-4 gap-1.5">
            <div className="p-1.5 rounded-xl bg-[#FFF0EC] text-[11px] font-bold text-[#D04860]">Tahsin</div>
            <div className="p-1.5 rounded-xl bg-[#FFF0EC] text-[11px] font-bold text-[#D04860]">Tahfidz</div>
            <div className="p-1.5 rounded-xl bg-[#FFF0EC] text-[11px] font-bold text-[#D04860]">Tilawah</div>
            <div className="p-1.5 rounded-xl bg-[#FFF0EC] text-[11px] font-bold text-[#D04860]">Tajwid</div>
          </div>
        </div>
      </div>
    );
  }

  // PAMFLET 3: Investasi Terbaik Bukan Gadget, Tapi Al-Qur'an
  if (id === 'pamflet-3') {
    return (
      <div className="bg-gradient-to-b from-[#FFF0F4] via-[#FFE5EE] to-[#FFF5FA] p-4 sm:p-5 rounded-2xl border border-[#FAD2E1] text-[#2C2B2A] select-none text-left">
        <div className="text-center mb-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/90 border border-[#FAD2E1] text-[#C44D68] text-xs font-semibold shadow-xs">
            <span>🌸 RuQun · Kelas Anak & Keluarga</span>
          </div>
          <h3 className="text-lg sm:text-xl font-extrabold text-[#991B3A] mt-2 leading-snug">
            Investasi Terbaik Bukan Gadget, Tapi Al-Qur'an
          </h3>
          <p className="text-[11px] text-[#803348] mt-1 leading-relaxed">
            Berikan hadiah paling berharga untuk masa depan anak. Al-Qur'an akan menjadi cahaya, penuntun, dan pelindungnya sepanjang hayat. ♡
          </p>
        </div>

        {/* 3 Keutamaan Cards */}
        <div className="space-y-2 my-3">
          <div className="p-3 rounded-2xl bg-white/90 border border-[#F8B4C8] flex items-start gap-3">
            <span className="w-8 h-8 rounded-full bg-[#FFE5EE] text-[#D04860] flex items-center justify-center text-sm shrink-0 mt-0.5">
              🤍
            </span>
            <div>
              <h4 className="text-xs font-bold text-[#991B3A]">Membentuk Akhlak Mulia</h4>
              <p className="text-[10px] text-[#554E48] leading-relaxed mt-0.5">
                Al-Qur'an membimbing anak menjadi pribadi yang baik, beradab, dan berakhlak mulia sedari dini.
              </p>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-white/90 border border-[#F8B4C8] flex items-start gap-3">
            <span className="w-8 h-8 rounded-full bg-[#FFE5EE] text-[#D04860] flex items-center justify-center text-sm shrink-0 mt-0.5">
              📖
            </span>
            <div>
              <h4 className="text-xs font-bold text-[#991B3A]">Bekal Dunia & Akhirat</h4>
              <p className="text-[10px] text-[#554E48] leading-relaxed mt-0.5">
                Ilmu Al-Qur'an adalah bekal terbaik dan investasi kekal untuk kehidupan di dunia dan akhirat.
              </p>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-white/90 border border-[#F8B4C8] flex items-start gap-3">
            <span className="w-8 h-8 rounded-full bg-[#FFE5EE] text-[#D04860] flex items-center justify-center text-sm shrink-0 mt-0.5">
              ⭐
            </span>
            <div>
              <h4 className="text-xs font-bold text-[#991B3A]">Pahala yang Mengalir</h4>
              <p className="text-[10px] text-[#554E48] leading-relaxed mt-0.5">
                Setiap huruf yang dibaca dan diamalkan anak menjadi pahala jariah bagi orang tua tanpa terputus.
              </p>
            </div>
          </div>
        </div>

        {/* Hadits */}
        <div className="p-3 bg-white/90 rounded-2xl border border-[#F8B4C8] text-center my-3">
          <p className="text-[11px] font-semibold text-[#803348] italic">
            “Sebaik-baik kalian adalah yang belajar Al-Qur'an dan mengajarkannya.”
          </p>
          <span className="text-[10px] text-[#A0526B] font-medium block mt-0.5">(HR. Bukhari)</span>
        </div>

        {/* Hadiahkan Anak Banner */}
        <div className="p-3 rounded-2xl bg-[#D04860] text-white text-center shadow-xs">
          <p className="text-xs font-bold">🎁 Hadiahkan Anak Kelas Mengaji Online di RuQun ♡</p>
          <p className="text-[10px] opacity-90 mt-0.5">
            Ustazah Berpengalaman · Kelas Interaktif · Jadwal Fleksibel · Belajar dari Rumah
          </p>
        </div>
      </div>
    );
  }

  // PAMFLET 4: Perubahan Setelah Belajar di RuQun (1000+ Santri)
  if (id === 'pamflet-4') {
    return (
      <div className="bg-gradient-to-b from-[#FFF5F7] via-[#FFEAF0] to-[#FFF0F4] p-4 sm:p-5 rounded-2xl border border-[#FAD2E1] text-[#2C2B2A] select-none text-left">
        <div className="text-center mb-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FDF8ED] border border-[#EADBB8] text-[#A87B2E] text-xs font-bold shadow-xs">
            <Star size={13} className="fill-[#C5A059] text-[#C5A059]" />
            <span>1000+ Santri Telah Merasakan Perubahannya</span>
          </div>
          <h3 className="text-lg sm:text-xl font-extrabold text-[#991B3A] mt-2 leading-snug">
            Perubahan Setelah Belajar di RuQun
          </h3>
          <p className="text-[11px] text-[#803348] mt-1">
            Dari ragu dan terbata, menjadi lancar dan percaya diri membaca Al-Qur'an ♡
          </p>
        </div>

        {/* 6 Poin Perubahan */}
        <div className="bg-white/95 rounded-2xl p-3 border border-[#F8B4C8] space-y-1.5 my-3 text-[10px]">
          <div className="flex items-center justify-between py-1 border-b border-[#FCECE9]">
            <span className="text-[#E63946] flex items-center gap-1"><X size={11} /> Bacaan belum lancar</span>
            <span className="font-bold text-[#7F998C]">➔</span>
            <span className="text-[#2A9D8F] font-semibold flex items-center gap-1"><Check size={11} strokeWidth={3} /> Makin lancar & bertajwid</span>
          </div>
          <div className="flex items-center justify-between py-1 border-b border-[#FCECE9]">
            <span className="text-[#E63946] flex items-center gap-1"><X size={11} /> Sering salah tajwid</span>
            <span className="font-bold text-[#7F998C]">➔</span>
            <span className="text-[#2A9D8F] font-semibold flex items-center gap-1"><Check size={11} strokeWidth={3} /> Tajwid makin tepat & benar</span>
          </div>
          <div className="flex items-center justify-between py-1 border-b border-[#FCECE9]">
            <span className="text-[#E63946] flex items-center gap-1"><X size={11} /> Hafalan masih sulit</span>
            <span className="font-bold text-[#7F998C]">➔</span>
            <span className="text-[#2A9D8F] font-semibold flex items-center gap-1"><Check size={11} strokeWidth={3} /> Hafalan bertambah terjaga</span>
          </div>
          <div className="flex items-center justify-between py-1 border-b border-[#FCECE9]">
            <span className="text-[#E63946] flex items-center gap-1"><X size={11} /> Belajar tidak terarah</span>
            <span className="font-bold text-[#7F998C]">➔</span>
            <span className="text-[#2A9D8F] font-semibold flex items-center gap-1"><Check size={11} strokeWidth={3} /> Terarah dgn pendampingan</span>
          </div>
          <div className="flex items-center justify-between py-1">
            <span className="text-[#E63946] flex items-center gap-1"><X size={11} /> Kurang konsisten</span>
            <span className="font-bold text-[#7F998C]">➔</span>
            <span className="text-[#2A9D8F] font-semibold flex items-center gap-1"><Check size={11} strokeWidth={3} /> Lebih konsisten & semangat</span>
          </div>
        </div>

        {/* 4 Statistik Capaian */}
        <div className="grid grid-cols-2 gap-2 text-center my-3">
          <div className="p-2.5 bg-white/90 rounded-2xl border border-[#F8B4C8]">
            <span className="text-[10px] text-[#6E4E45] block">Peningkatan Bacaan</span>
            <strong className="text-base font-extrabold text-[#D04860] block">85%</strong>
            <span className="text-[9px] text-[#C5A059]">⭐⭐⭐⭐⭐</span>
          </div>
          <div className="p-2.5 bg-white/90 rounded-2xl border border-[#F8B4C8]">
            <span className="text-[10px] text-[#6E4E45] block">Pemahaman Tajwid</span>
            <strong className="text-base font-extrabold text-[#2A9D8F] block">90%</strong>
            <span className="text-[9px] text-[#C5A059]">⭐⭐⭐⭐⭐</span>
          </div>
          <div className="p-2.5 bg-white/90 rounded-2xl border border-[#F8B4C8]">
            <span className="text-[10px] text-[#6E4E45] block">Hafalan per Bulan</span>
            <strong className="text-base font-extrabold text-[#A87B2E] block">1-5 Halaman</strong>
            <span className="text-[9px] text-[#C5A059]">⭐⭐⭐⭐⭐</span>
          </div>
          <div className="p-2.5 bg-white/90 rounded-2xl border border-[#F8B4C8]">
            <span className="text-[10px] text-[#6E4E45] block">Kepuasan Santri</span>
            <strong className="text-base font-extrabold text-[#991B3A] block">98%</strong>
            <span className="text-[9px] text-[#C5A059]">⭐⭐⭐⭐⭐</span>
          </div>
        </div>

        <div className="text-center p-2 rounded-xl bg-[#FFF0F4] border border-[#F8B4C8] text-[10px] text-[#803348] font-semibold">
          ✨ Mulai Perubahanmu Hari Ini Bersama RuQun!
        </div>
      </div>
    );
  }

  // PAMFLET 5: Pendaftaran Kelas Belajar Al-Quran (+2500 Santri)
  return (
    <div className="bg-gradient-to-b from-[#FFF0F3] via-[#FFE8ED] to-[#FFF5F8] p-4 sm:p-5 rounded-2xl border border-[#FAD2E1] text-[#2C2B2A] select-none text-left">
      <div className="text-center mb-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/90 border border-[#FAD2E1] text-[#C44D68] text-xs font-semibold shadow-xs">
          <span>🌸 Rumah Qur'an Nur Hidayah</span>
        </div>
        <h3 className="text-lg sm:text-xl font-extrabold text-[#991B3A] mt-2 leading-tight">
          Pendaftaran Kelas Belajar Al-Qur'an
        </h3>
        <p className="text-[11px] text-[#803348] mt-1 leading-relaxed">
          Belajar Al-Qur'an secara online, fleksibel, dan dibimbing oleh pengajar yang berkompeten.
        </p>

        {/* Big Stat Badge */}
        <div className="my-2.5 inline-block p-2.5 px-4 rounded-2xl bg-[#D04860] text-white shadow-xs text-center">
          <span className="text-[10px] uppercase font-bold tracking-wider block opacity-90">Telah Diikuti Oleh</span>
          <span className="text-xl font-black block leading-none my-0.5">+2500 Santri</span>
          <span className="text-[10px] block opacity-90">di Seluruh Indonesia ⭐</span>
        </div>
      </div>

      {/* Program Kami */}
      <div className="grid grid-cols-2 gap-2 my-3">
        <div className="p-3 bg-white/95 rounded-2xl border border-[#F8B4C8] text-center shadow-xs">
          <span className="text-base block mb-0.5">📖</span>
          <h4 className="text-xs font-bold text-[#991B3A]">Kelas Tahsin</h4>
          <span className="text-[10px] text-[#6E4E45] block mt-0.5">Memperbaiki makhraj & kaidah tajwid</span>
        </div>
        <div className="p-3 bg-white/95 rounded-2xl border border-[#F8B4C8] text-center shadow-xs">
          <span className="text-base block mb-0.5">📗</span>
          <h4 className="text-xs font-bold text-[#991B3A]">Kelas Tahfidz</h4>
          <span className="text-[10px] text-[#6E4E45] block mt-0.5">Bimbingan hafalan terarah & mutqin</span>
        </div>
      </div>

      {/* Keunggulan Kami List */}
      <div className="bg-white/90 rounded-2xl p-3 border border-[#F8B4C8] space-y-1.5 text-[11px] text-[#4A4541]">
        <div className="flex items-center gap-2">
          <span className="w-4 h-4 rounded-full bg-[#B7E4C7] text-[#1B4332] flex items-center justify-center text-[10px] font-bold shrink-0">✓</span>
          <span>Program belajar Al-Qur'an online</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-4 h-4 rounded-full bg-[#B7E4C7] text-[#1B4332] flex items-center justify-center text-[10px] font-bold shrink-0">✓</span>
          <span><strong>Ikhwan & Akhwat (Kelas Terpisah)</strong></span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-4 h-4 rounded-full bg-[#B7E4C7] text-[#1B4332] flex items-center justify-center text-[10px] font-bold shrink-0">✓</span>
          <span>Cocok untuk semua usia (anak, remaja, dewasa)</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-4 h-4 rounded-full bg-[#B7E4C7] text-[#1B4332] flex items-center justify-center text-[10px] font-bold shrink-0">✓</span>
          <span>Pilihan kelas privat atau reguler</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-4 h-4 rounded-full bg-[#B7E4C7] text-[#1B4332] flex items-center justify-center text-[10px] font-bold shrink-0">✓</span>
          <span>Pembelajaran dilakukan secara online</span>
        </div>
      </div>

      <div className="mt-3 text-center text-[10px] text-[#803348] font-medium">
        🌐 ruqun.id · Rumah Qur'an Nur Hidayah
      </div>
    </div>
  );
};
