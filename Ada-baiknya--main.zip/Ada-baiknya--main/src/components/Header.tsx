import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Info, X, Sparkles, BookOpen, Heart, GraduationCap, User } from 'lucide-react';

export const Header: React.FC = () => {
  const { profile, setIsProfileModalOpen } = useApp();
  const [showInfo, setShowInfo] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-30 bg-[#FAF7F2]/95 backdrop-blur-md border-b border-[#EFE8DF]/80 px-4 py-2.5 transition-colors">
        <div className="max-w-md mx-auto flex items-center justify-between">
          {/* Brand */}
          <div className="flex items-center gap-2.5">
            <span className="w-8 h-8 rounded-full bg-[#F5E6E3] border border-[#ECD1CC] flex items-center justify-center text-[#C47366] text-sm shadow-xs">
              🌷
            </span>
            <div>
              <h1 className="text-base font-bold tracking-tight text-[#2C2B2A] flex items-center gap-1.5 leading-tight">
                <span>Ada Baiknya</span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059]" />
              </h1>
              <p className="text-[10px] text-[#8C847E] font-medium leading-none">
                Ruang Tenang Muslimah
              </p>
            </div>
          </div>

          {/* Right Action: Profile Trigger & Info Trigger */}
          <div className="flex items-center gap-1.5">
            {/* Profil Pengguna Trigger Button */}
            <button
              onClick={() => setIsProfileModalOpen(true)}
              className="flex items-center gap-1.5 py-1 px-2.5 rounded-2xl bg-white border border-[#EFE8DF] hover:border-[#E8A598] hover:bg-[#FDF9F8] shadow-2xs transition-all text-left"
              aria-label="Buka Profil Pengguna"
            >
              <span className="w-6 h-6 rounded-full bg-[#F8EDE9] border border-[#F1DDD7] text-xs flex items-center justify-center shrink-0">
                {profile.avatarIcon || '🌷'}
              </span>
              <span className="text-xs font-semibold text-[#2C2B2A] max-w-[80px] truncate">
                {profile.name || 'Profil'}
              </span>
            </button>

            {/* Info Dialog Trigger */}
            <button
              onClick={() => setShowInfo(true)}
              className="w-8 h-8 rounded-2xl flex items-center justify-center text-[#857E78] hover:text-[#C47366] hover:bg-[#F3EBE3] transition-colors"
              aria-label="Tentang Ada Baiknya"
            >
              <Info size={17} strokeWidth={1.8} />
            </button>
          </div>
        </div>
      </header>

      {/* Info Dialog */}
      {showInfo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#FFFFFF] border border-[#EFE8DF] rounded-3xl max-w-sm w-full p-6 shadow-2xl relative text-left">
            <button
              onClick={() => setShowInfo(false)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center text-[#857E78] hover:bg-[#FAF7F2] transition-colors"
              aria-label="Tutup"
            >
              <X size={18} />
            </button>

            <div className="w-12 h-12 rounded-2xl bg-[#F8EDE9] border border-[#F1DDD7] flex items-center justify-center text-[#C47366] mb-3 text-xl shadow-xs">
              🌷
            </div>

            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-lg font-bold text-[#2C2B2A]">
                Ada Baiknya
              </h3>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#FDF8ED] text-[#A87B2E] border border-[#EADBB8]">
                Ruang Muslimah
              </span>
            </div>

            <p className="text-xs text-[#C47366] font-medium mb-3 italic">
              “Sedikit demi sedikit, menjadi lebih baik.”
            </p>

            <p className="text-xs text-[#5C5752] leading-relaxed mb-4">
              Sebuah ruang digital sederhana dan tenang bagi muslimah untuk menata rutinitas harian, ibadah, dan belajar bertahap tanpa rasa tertekan.
            </p>

            {/* 3 Menu Highlights */}
            <div className="space-y-2 mb-4">
              <div className="p-2.5 bg-[#FAF7F2] rounded-xl border border-[#EFE8DF] flex items-center gap-2.5">
                <BookOpen size={15} className="text-[#C47366] shrink-0" />
                <div className="text-[11px]">
                  <strong className="text-[#2C2B2A]">Ruang Catatan:</strong> Checklist harian, refleksi, habit, jurnal, dan target.
                </div>
              </div>
              <div className="p-2.5 bg-[#FAF7F2] rounded-xl border border-[#EFE8DF] flex items-center gap-2.5">
                <Heart size={15} className="text-[#7F998C] shrink-0" />
                <div className="text-[11px]">
                  <strong className="text-[#2C2B2A]">Ruang Qur'an:</strong> Tracker shalat 5 waktu, tilawah halaman, dzikir, dan kebaikan.
                </div>
              </div>
              <div className="p-2.5 bg-[#FAF7F2] rounded-xl border border-[#EFE8DF] flex items-center gap-2.5">
                <GraduationCap size={15} className="text-[#C5A059] shrink-0" />
                <div className="text-[11px]">
                  <strong className="text-[#2C2B2A]">Ruang Belajar:</strong> Katalog program belajar Muslimah & program unggulan RUQUN.
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowInfo(false)}
              className="w-full py-2.5 rounded-xl bg-[#C47366] text-white text-xs font-semibold hover:bg-[#B35F52] shadow-xs transition-colors"
            >
              Tutup & Lanjutkan
            </button>
          </div>
        </div>
      )}
    </>
  );
};
