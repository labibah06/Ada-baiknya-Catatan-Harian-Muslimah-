import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  User,
  Sparkles,
  BookOpen,
  Heart,
  Save,
  RotateCcw,
  ShieldCheck,
  Check,
  Flame,
  Target,
  Download,
} from 'lucide-react';

const avatarOptions = [
  { icon: '🌷', label: 'Tulip' },
  { icon: '🌸', label: 'Sakura' },
  { icon: '🌿', label: 'Sage' },
  { icon: '🌹', label: 'Mawar' },
  { icon: '✨', label: 'Bintang' },
  { icon: '🕊️', label: 'Merpati' },
  { icon: '☀️', label: 'Mentari' },
  { icon: '📖', label: 'Kitab' },
];

const callSignOptions = ['Ukhti', 'Bunda', 'Sahabat', 'Mbak', 'Ibu'];

export const ProfileModal: React.FC = () => {
  const {
    profile,
    updateProfile,
    isProfileModalOpen,
    setIsProfileModalOpen,
    habits,
    journals,
    targets,
    tilawah,
    updateTilawahGoal,
    showToast,
  } = useApp();

  // Local form state
  const [nameInput, setNameInput] = useState(profile.name);
  const [callSignInput, setCallSignInput] = useState(profile.callSign);
  const [avatarInput, setAvatarInput] = useState(profile.avatarIcon);
  const [bioInput, setBioInput] = useState(profile.bio);
  const [dailyNiatInput, setDailyNiatInput] = useState(profile.dailyNiat);
  const [tilawahTargetInput, setTilawahTargetInput] = useState(
    profile.tilawahDailyTarget || tilawah.dailyGoal || 2
  );

  if (!isProfileModalOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const finalName = nameInput.trim() || 'Fathimah';
    updateProfile({
      name: finalName,
      callSign: callSignInput,
      avatarIcon: avatarInput,
      bio: bioInput.trim(),
      dailyNiat: dailyNiatInput.trim(),
      tilawahDailyTarget: Number(tilawahTargetInput),
    });
    // Also sync tilawah daily goal
    updateTilawahGoal(Number(tilawahTargetInput));
    setIsProfileModalOpen(false);
  };

  // Compute summary stats
  const maxStreak = habits.reduce((max, h) => Math.max(max, h.streak), 0);
  const ongoingTargetsCount = targets.filter((t) => t.status === 'ongoing').length;

  const handleExportData = () => {
    try {
      const dataToExport = {
        profile: { ...profile, name: nameInput, callSign: callSignInput },
        journals,
        targets,
        habits: habits.map((h) => ({ name: h.name, streak: h.streak, category: h.category })),
        exportedAt: new Date().toISOString(),
      };
      const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(
        JSON.stringify(dataToExport, null, 2)
      )}`;
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute('href', jsonString);
      downloadAnchor.setAttribute('download', `ada-baiknya-catatan-${nameInput || 'muslimah'}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      showToast('Data berhasil dicadangkan 📥');
    } catch {
      showToast('Gagal mencadangkan data');
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={() => setIsProfileModalOpen(false)}
    >
      <div
        className="bg-white rounded-3xl max-w-md w-full max-h-[92vh] flex flex-col shadow-2xl relative border border-[#EFE8DF] overflow-hidden text-left"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Bar */}
        <div className="p-4 sm:p-5 border-b border-[#F0EAE1] flex items-center justify-between bg-[#FAF7F2]">
          <div className="flex items-center gap-2.5">
            <span className="w-9 h-9 rounded-2xl bg-[#F8EDE9] border border-[#F1DDD7] text-lg flex items-center justify-center shadow-xs">
              {avatarInput}
            </span>
            <div>
              <h3 className="text-base font-bold text-[#2C2B2A]">
                Profil & Pengaturan Diri
              </h3>
              <p className="text-[11px] text-[#8C847E]">
                Ruang pribadi untuk menata niat dan preferensi
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setIsProfileModalOpen(false)}
            className="w-8 h-8 rounded-full bg-white border border-[#EFE8DF] flex items-center justify-center text-[#7A746E] hover:bg-[#FAF7F2] shrink-0"
            aria-label="Tutup"
          >
            <X size={16} />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <div className="overflow-y-auto p-4 sm:p-5 space-y-4 flex-1">
          {/* Ringkasan Istiqomah Card */}
          <div className="grid grid-cols-3 gap-2 p-3 bg-gradient-to-r from-[#FAF7F2] to-[#FDF8ED] rounded-2xl border border-[#EFE8DF]">
            <div className="text-center">
              <span className="text-[10px] text-[#8C847E] block">Streak Terbaik</span>
              <span className="text-sm font-bold text-[#C47366] flex items-center justify-center gap-1">
                <Flame size={13} className="fill-[#C47366]" />
                <span>{maxStreak} hari</span>
              </span>
            </div>
            <div className="text-center border-x border-[#EFE8DF]">
              <span className="text-[10px] text-[#8C847E] block">Jurnal Hati</span>
              <span className="text-sm font-bold text-[#7F998C] flex items-center justify-center gap-1">
                <BookOpen size={13} />
                <span>{journals.length} tulisan</span>
              </span>
            </div>
            <div className="text-center">
              <span className="text-[10px] text-[#8C847E] block">Target Aktif</span>
              <span className="text-sm font-bold text-[#A87B2E] flex items-center justify-center gap-1">
                <Target size={13} />
                <span>{ongoingTargetsCount} target</span>
              </span>
            </div>
          </div>

          <form onSubmit={handleSave} className="space-y-4">
            {/* 1. Nama & Panggilan */}
            <div className="grid grid-cols-3 gap-2">
              <div className="col-span-1">
                <label className="block text-xs font-semibold text-[#4A4541] mb-1">
                  Sapaan
                </label>
                <select
                  value={callSignInput}
                  onChange={(e) => setCallSignInput(e.target.value)}
                  className="w-full text-xs text-[#2C2B2A] p-2.5 rounded-xl bg-[#FAF7F2] border border-[#EFE8DF] focus:outline-hidden focus:border-[#C47366]"
                >
                  {callSignOptions.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              </div>

              <div className="col-span-2">
                <label className="block text-xs font-semibold text-[#4A4541] mb-1">
                  Nama Kamu
                </label>
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  placeholder="Contoh: Fathimah, Aisyah…"
                  className="w-full text-xs text-[#2C2B2A] p-2.5 rounded-xl bg-[#FAF7F2] border border-[#EFE8DF] focus:outline-hidden focus:border-[#C47366] focus:bg-white transition-all"
                  required
                />
              </div>
            </div>

            {/* 2. Pilihan Avatar Simbolik (Bebas Wajah Manusia) */}
            <div>
              <label className="block text-xs font-semibold text-[#4A4541] mb-1.5">
                Pilih Simbol Avatar
              </label>
              <div className="grid grid-cols-4 gap-2">
                {avatarOptions.map((item) => {
                  const isSelected = avatarInput === item.icon;
                  return (
                    <button
                      key={item.label}
                      type="button"
                      onClick={() => setAvatarInput(item.icon)}
                      className={`flex flex-col items-center justify-center p-2 rounded-2xl border transition-all ${
                        isSelected
                          ? 'bg-[#F8EDE9] border-[#E8A598] text-[#C47366] shadow-xs scale-102 font-medium'
                          : 'bg-[#FAF7F2] border-[#EFE8DF] hover:bg-white text-[#6E6862]'
                      }`}
                    >
                      <span className="text-xl mb-0.5">{item.icon}</span>
                      <span className="text-[10px]">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. Niat & Doa Hari Ini */}
            <div>
              <label className="block text-xs font-semibold text-[#4A4541] mb-1">
                Niat / Pengingat Pribadi
              </label>
              <input
                type="text"
                value={dailyNiatInput}
                onChange={(e) => setDailyNiatInput(e.target.value)}
                placeholder="Contoh: Bismillah, melangkah dengan tenang dan ikhlas…"
                className="w-full text-xs text-[#2C2B2A] p-2.5 rounded-xl bg-[#FAF7F2] border border-[#EFE8DF] focus:outline-hidden focus:border-[#C47366] focus:bg-white transition-all"
              />
            </div>

            {/* 4. Bio Singkat */}
            <div>
              <label className="block text-xs font-semibold text-[#4A4541] mb-1">
                Tentang Diri Singkat (Bio)
              </label>
              <textarea
                rows={2}
                value={bioInput}
                onChange={(e) => setBioInput(e.target.value)}
                placeholder="Tuliskan kata-kata yang menenangkan untuk dirimu…"
                className="w-full text-xs text-[#2C2B2A] p-2.5 rounded-xl bg-[#FAF7F2] border border-[#EFE8DF] focus:outline-hidden focus:border-[#C47366] focus:bg-white transition-all resize-none leading-relaxed"
              />
            </div>

            {/* 5. Target Tilawah Harian Default */}
            <div>
              <label className="block text-xs font-semibold text-[#4A4541] mb-1.5">
                Target Tilawah Qur'an Harian
              </label>
              <div className="grid grid-cols-4 gap-1.5">
                {[1, 2, 5, 10].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setTilawahTargetInput(num)}
                    className={`py-1.5 px-2 rounded-xl border text-xs font-medium transition-all ${
                      Number(tilawahTargetInput) === num
                        ? 'bg-[#EDF3F0] border-[#94AC9F] text-[#4E7060]'
                        : 'bg-[#FAF7F2] border-[#EFE8DF] text-[#6E6862]'
                    }`}
                  >
                    {num} Halaman
                  </button>
                ))}
              </div>
            </div>

            {/* Cadangkan Data Button */}
            <div className="pt-2 border-t border-[#F5EFE9] flex items-center justify-between text-xs text-[#8C847E]">
              <span>Cadangkan data catatan ke file:</span>
              <button
                type="button"
                onClick={handleExportData}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-[#FAF7F2] hover:bg-[#F0EAE1] text-[#4A4541] border border-[#EFE8DF] transition-colors font-medium text-[11px]"
              >
                <Download size={13} />
                <span>Unduh Cadangan</span>
              </button>
            </div>

            {/* Actions */}
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsProfileModalOpen(false)}
                className="flex-1 py-2.5 rounded-xl border border-[#EFE8DF] text-xs font-medium text-[#6E6862] hover:bg-[#FAF7F2]"
              >
                Batal
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 rounded-xl bg-[#C47366] text-white text-xs font-semibold hover:bg-[#B35F52] shadow-xs transition-colors"
              >
                Simpan Profil 🌸
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
