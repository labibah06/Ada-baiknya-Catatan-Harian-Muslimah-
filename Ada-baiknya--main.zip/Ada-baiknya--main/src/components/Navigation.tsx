import React from 'react';
import { useApp } from '../context/AppContext';
import { TabType } from '../types';
import { BookOpen, Heart, GraduationCap } from 'lucide-react';

interface NavItem {
  id: TabType;
  label: string;
  icon: React.ComponentType<{ className?: string; size?: number; strokeWidth?: number }>;
}

const navItems: NavItem[] = [
  { id: 'catatan', label: 'Ruang Catatan', icon: BookOpen },
  { id: 'quran', label: "Ruang Qur'an", icon: Heart },
  { id: 'belajar', label: 'Ruang Belajar', icon: GraduationCap },
];

export const Navigation: React.FC = () => {
  const { activeTab, setActiveTab, setRuqunDetailOpen } = useApp();

  const handleTabClick = (id: TabType) => {
    setActiveTab(id);
    if (id !== 'belajar') {
      setRuqunDetailOpen(false);
    }
  };

  return (
    <nav
      aria-label="Navigasi Utama"
      className="fixed bottom-0 left-0 right-0 z-40 bg-[#FAF7F2]/95 backdrop-blur-md border-t border-[#EFE8DF] px-3 pb-safe"
    >
      <div className="max-w-md mx-auto grid grid-cols-3 h-16 items-center">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          const IconComponent = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => handleTabClick(item.id)}
              className={`flex flex-col items-center justify-center min-h-[48px] py-1 transition-all duration-200 rounded-2xl relative ${
                isActive
                  ? 'text-[#C47366] font-medium'
                  : 'text-[#857E78] hover:text-[#4A4541]'
              }`}
              aria-current={isActive ? 'page' : undefined}
            >
              {/* Active soft glow pill with gentle rose/gold tint */}
              {isActive && (
                <span className="absolute top-1 w-12 h-7 bg-[#F7EBE8] rounded-full -z-10 transition-transform scale-100" />
              )}
              <IconComponent
                size={21}
                strokeWidth={isActive ? 2.3 : 1.8}
                className={`transition-transform duration-200 ${
                  isActive ? 'scale-105 text-[#C47366]' : ''
                }`}
              />
              <span
                className={`text-[11px] tracking-tight mt-1 whitespace-nowrap transition-colors ${
                  isActive ? 'font-semibold text-[#B35F52]' : 'font-normal'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
