/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { ToastContainer } from './components/Toast';
import { ProfileModal } from './components/ProfileModal';
import { RuangCatatanView } from './views/RuangCatatanView';
import { RuangQuranView } from './views/RuangQuranView';
import { RuangBelajarView } from './views/RuangBelajarView';
import { RuqunDetailView } from './views/RuqunDetailView';

const MainContent: React.FC = () => {
  const { activeTab, ruqunDetailOpen } = useApp();

  return (
    <main className="max-w-md mx-auto px-4 pt-3 pb-24 min-h-screen">
      {activeTab === 'catatan' && <RuangCatatanView />}
      {activeTab === 'quran' && <RuangQuranView />}
      {activeTab === 'belajar' && (ruqunDetailOpen ? <RuqunDetailView /> : <RuangBelajarView />)}
    </main>
  );
};

export default function App() {
  return (
    <AppProvider>
      <div className="min-h-screen bg-[#FAF7F2] text-[#2C2B2A] relative flex flex-col font-sans selection:bg-[#F3D6CF]">
        <ToastContainer />
        <Header />
        <ProfileModal />
        <div className="flex-1 w-full">
          <MainContent />
        </div>
        <Navigation />
      </div>
    </AppProvider>
  );
}
