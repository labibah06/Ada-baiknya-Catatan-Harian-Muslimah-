// Utility for storing and retrieving pamphlet images locally via IndexedDB

const DB_NAME = 'AdaBaiknyaPamfletDB';
const STORE_NAME = 'pamflet_images';
const DB_VERSION = 1;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
  });
}

export async function savePamphletImage(id: string, dataUrl: string): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.put(dataUrl, id);
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    // Fallback to localStorage if IndexedDB fails
    try {
      localStorage.setItem(`pamflet_img_${id}`, dataUrl);
    } catch {
      console.warn('Storage quota exceeded');
    }
  }
}

export async function getPamphletImage(id: string): Promise<string | null> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const req = store.get(id);
    return new Promise((resolve) => {
      req.onsuccess = () => {
        if (req.result) {
          resolve(req.result as string);
        } else {
          // Check fallback localStorage
          const local = localStorage.getItem(`pamflet_img_${id}`);
          resolve(local || null);
        }
      };
      req.onerror = () => {
        const local = localStorage.getItem(`pamflet_img_${id}`);
        resolve(local || null);
      };
    });
  } catch {
    const local = localStorage.getItem(`pamflet_img_${id}`);
    return local || null;
  }
}

export async function clearPamphletImage(id: string): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.delete(id);
  } catch {
    // ignore
  }
  localStorage.removeItem(`pamflet_img_${id}`);
}
