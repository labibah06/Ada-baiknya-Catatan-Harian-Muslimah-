import React from 'react';
import { IbadahView } from './IbadahView';

export const RuangQuranView: React.FC = () => {
  return (
    <div className="space-y-4">
      <IbadahView />
    </div>
  );
};
