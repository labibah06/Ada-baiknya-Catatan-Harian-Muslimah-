import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Check,
  Plus,
  Flame,
  Trash2,
  X,
  Sparkles,
  CalendarDays,
} from 'lucide-react';
import { HabitItem } from '../types';

export const HabitView: React.FC = () => {
  const { habits, toggleHabit, addHabit, deleteHabit } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [nameInput, setNameInput] = useState('');
  const [frequencyInput, setFrequencyInput] = useState('Setiap Hari');
  const [categoryInput, setCategoryInput] = useState<HabitItem['category']>('rutinitas');
  const [errorMessage, setErrorMessage] = useState('');

  const completedTodayCount = habits.filter((h) => h.completedToday).length;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim()) {
      setErrorMessage('Silakan isi nama habit terlebih dahulu 🌸');
      return;
    }

    addHabit({
      name: nameInput.trim(),
      frequency: frequencyInput,
      category: categoryInput,
    });

    setNameInput('');
    setFrequencyInput('Setiap Hari');
    setCategoryInput('rutinitas');
    setErrorMessage('');
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-300">
      {/* Title & Subtitle */}
      <div className="pt-2 px-1">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-[#2C2B2A]">
              Habit Baik
            </h2>
            <p className="text-xs text-[#857E78] mt-1">
              “Kebiasaan kecil yang dilakukan konsisten bisa menjadi perubahan besar.”
            </p>
          </div>
          <button
            onClick={() => {
              setErrorMessage('');
              setIsModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#C47366] text-white text-xs font-medium hover:bg-[#B35F52] active:scale-95 transition-all shadow-xs shrink-0"
          >
            <Plus size={15} />
            <span>Tambah</span>
          </button>
        </div>
      </div>

      {/* Overview Stat Card */}
      <div className="bg-white rounded-3xl p-4 border border-[#EFE8DF] shadow-[0_2px_12px_rgba(196,115,102,0.06)] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#F8EDE9] flex items-center justify-center text-[#C47366]">
            <Flame size={20} />
          </div>
          <div>
            <p className="text-xs text-[#857E78]">Selesai Hari Ini</p>
            <p className="text-base font-bold text-[#2C2B2A] tabular-nums">
              {completedTodayCount} dari {habits.length} kebiasaan
            </p>
          </div>
        </div>

        <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-[#FAF7F2] text-[#7F998C] border border-[#EFE8DF]">
          {completedTodayCount === habits.length && habits.length > 0
            ? 'Hebat! ✨'
            : 'Terus melangkah 🌱'}
        </span>
      </div>

      {/* List of Habits */}
      <div className="space-y-3">
        {habits.map((habit) => {
          return (
            <div
              key={habit.id}
              className={`p-4 rounded-3xl border transition-all duration-200 bg-white ${
                habit.completedToday
                  ? 'border-[#E8DDD1] shadow-xs'
                  : 'border-[#EFE8DF] hover:border-[#DFD4C6]'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <button
                  type="button"
                  onClick={() => toggleHabit(habit.id)}
                  className="flex items-start gap-3.5 text-left flex-1 min-h-[44px]"
                >
                  {/* Checkbox */}
                  <div
                    className={`w-6 h-6 rounded-lg mt-0.5 flex items-center justify-center shrink-0 transition-all ${
                      habit.completedToday
                        ? 'bg-[#C47366] text-white shadow-xs'
                        : 'border-2 border-[#D8CFC5] bg-white hover:border-[#C47366]'
                    }`}
                  >
                    {habit.completedToday && <Check size={14} strokeWidth={2.8} />}
                  </div>

                  <div>
                    <h3
                      className={`text-sm font-semibold transition-colors ${
                        habit.completedToday
                          ? 'line-through text-[#99928A]'
                          : 'text-[#2C2B2A]'
                      }`}
                    >
                      {habit.name}
                    </h3>

                    {/* Metadata unboxed text with subtle separator */}
                    <div className="flex items-center gap-2 text-[11px] text-[#857E78] mt-1">
                      <span>{habit.frequency}</span>
                      <span aria-hidden="true">·</span>
                      <span className="capitalize">{habit.category}</span>
                    </div>
                  </div>
                </button>

                <div className="flex items-center gap-2 shrink-0">
                  {/* Streak indicator */}
                  <div className="flex items-center gap-1 text-xs font-semibold text-[#C47366] bg-[#F8EDE9] px-2.5 py-1 rounded-xl">
                    <Flame size={13} className="text-[#C47366] fill-[#C47366]" />
                    <span className="tabular-nums">{habit.streak} hari</span>
                  </div>

                  {/* Delete button */}
                  <button
                    onClick={() => deleteHabit(habit.id)}
                    className="w-8 h-8 rounded-xl flex items-center justify-center text-[#B0A79E] hover:text-[#C47366] hover:bg-[#FAF7F2] transition-colors"
                    aria-label={`Hapus habit ${habit.name}`}
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>

              {/* 7-day mini progress dots */}
              <div className="mt-3 pt-3 border-t border-[#F5EFE9] flex items-center justify-between">
                <span className="text-[10px] text-[#9E968E]">Catatan 7 hari terakhir:</span>
                <div className="flex items-center gap-1.5">
                  {habit.last7Days.map((done, idx) => (
                    <span
                      key={idx}
                      className={`w-3.5 h-3.5 rounded-full flex items-center justify-center transition-colors ${
                        done
                          ? 'bg-[#C47366]'
                          : 'bg-[#EDE7DE] border border-[#DDD5CA]'
                      }`}
                      title={done ? 'Tercapai' : 'Belum'}
                    />
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal / Bottom Sheet: + Tambah Habit */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/35 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-xl relative border border-[#EFE8DF]">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold text-[#2C2B2A]">
                Tambah Habit Baru
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-[#857E78] hover:bg-[#FAF7F2] transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            {errorMessage && (
              <div className="mb-3 p-2.5 rounded-xl bg-[#FCECE9] text-xs text-[#C47366]">
                {errorMessage}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#4A4541] mb-1.5">
                  Nama Habit
                </label>
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  placeholder="Contoh: Dhuha 2 rakaat, Minum air 2 liter…"
                  className="w-full text-xs text-[#2C2B2A] p-3 rounded-xl bg-[#FAF7F2] border border-[#EFE8DF] focus:outline-hidden focus:border-[#C47366] focus:bg-white transition-all placeholder:text-[#A09890]"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#4A4541] mb-1.5">
                  Frekuensi
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['Setiap Hari', 'Hari Kerja', 'Akhir Pekan'].map((freq) => (
                    <button
                      key={freq}
                      type="button"
                      onClick={() => setFrequencyInput(freq)}
                      className={`py-2 px-2 text-xs rounded-xl border transition-all ${
                        frequencyInput === freq
                          ? 'bg-[#F8EDE9] border-[#E8A598] text-[#C47366] font-medium'
                          : 'bg-[#FAF7F2] border-[#EFE8DF] text-[#6E6862]'
                      }`}
                    >
                      {freq}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#4A4541] mb-1.5">
                  Kategori
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { key: 'ibadah', label: '🕌 Ibadah' },
                    { key: 'kesehatan', label: '🥗 Kesehatan' },
                    { key: 'mindset', label: '📖 Mindset' },
                    { key: 'rutinitas', label: '🪴 Rutinitas' },
                  ].map((cat) => (
                    <button
                      key={cat.key}
                      type="button"
                      onClick={() => setCategoryInput(cat.key as HabitItem['category'])}
                      className={`py-2 px-2.5 text-xs text-left rounded-xl border transition-all ${
                        categoryInput === cat.key
                          ? 'bg-[#F8EDE9] border-[#E8A598] text-[#C47366] font-medium'
                          : 'bg-[#FAF7F2] border-[#EFE8DF] text-[#6E6862]'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-[#EFE8DF] text-xs font-medium text-[#6E6862] hover:bg-[#FAF7F2]"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#C47366] text-white text-xs font-medium hover:bg-[#B35F52] shadow-xs"
                >
                  Simpan Habit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
