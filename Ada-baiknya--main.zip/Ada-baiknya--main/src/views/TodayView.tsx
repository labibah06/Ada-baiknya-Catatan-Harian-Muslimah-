import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MoodType } from '../types';
import {
  Check,
  CheckCircle2,
  Calendar,
  Sparkles,
  Heart,
  BookOpen,
  Send,
  Smile,
  ShieldCheck,
} from 'lucide-react';

interface MoodOption {
  type: MoodType;
  emoji: string;
  label: string;
  color: string;
}

const moods: MoodOption[] = [
  { type: 'senang', emoji: '😊', label: 'Senang', color: '#E8A598' },
  { type: 'baik', emoji: '🙂', label: 'Baik', color: '#7F998C' },
  { type: 'biasa', emoji: '😐', label: 'Biasa saja', color: '#9CA3AF' },
  { type: 'sedih', emoji: '😔', label: 'Sedih', color: '#A0AEC0' },
  { type: 'lelah', emoji: '😴', label: 'Lelah', color: '#D4A373' },
];

export const TodayView: React.FC = () => {
  const {
    tasks,
    toggleTask,
    reflection,
    saveReflection,
    reflectionSavedStatus,
    gratitude,
    saveGratitude,
    gratitudeSavedStatus,
    mood,
    setMood,
    weeklySummary,
    setActiveTab,
    addJournal,
    setCatatanSubTab,
    showToast,
    profile,
    setIsProfileModalOpen,
  } = useApp();

  // Local state for forms
  const [halBaik, setHalBaik] = useState(reflection.halBaik);
  const [perbaikanBesok, setPerbaikanBesok] = useState(reflection.perbaikanBesok);
  const [gratitudeText, setGratitudeText] = useState(gratitude.text);

  // Calculate daily progress
  const completedTasksCount = tasks.filter((t) => t.completed).length;
  const totalTasksCount = tasks.length;
  const progressPercentage =
    totalTasksCount > 0 ? Math.round((completedTasksCount / totalTasksCount) * 100) : 0;

  const handleReflectionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveReflection({ halBaik, perbaikanBesok });
  };

  const handleSaveAsJournal = () => {
    saveReflection({ halBaik, perbaikanBesok });
    const todayFormatted = new Intl.DateTimeFormat('id-ID', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }).format(new Date());

    const content = `[Hal baik hari ini]\n${halBaik || 'Alhamdulillah hari ini terisi hal baik.'}\n\n[Yang ingin kuperbaiki besok]\n${perbaikanBesok || 'Melangkah lebih teratur dan tenang.'}`;

    addJournal({
      title: 'Refleksi Harian: Hal Baik & Perbaikan Diri',
      content,
      mood: mood || 'baik',
      date: todayFormatted,
    });

    setCatatanSubTab('jurnal');
    showToast('Tersimpan ke Jurnal Refleksi 📖');
  };

  const handleGratitudeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveGratitude(gratitudeText);
  };

  // Encouragement quote based on progress
  const getProgressEncouragement = () => {
    if (progressPercentage === 100) {
      return 'MasyaAllah, hari ini terisi dengan hal-hal penuh berkah 🌸';
    }
    if (progressPercentage >= 60) {
      return 'Alhamdulillah, langkahmu hari ini sudah luar biasa 💗';
    }
    if (progressPercentage > 0) {
      return 'Satu langkah kecil tetap berarti. Pelan-pelan saja ✨';
    }
    return 'Hari baru, kesempatan baru untuk berbuat baik 🌱';
  };

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-300">
      {/* 1. Header Salam & Tanggal */}
      <div className="pt-2 px-1">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-[#2C2B2A] flex items-center gap-2">
              <span>Assalamu’alaikum, {profile.name}</span>
              <span className="text-xl">{profile.avatarIcon}</span>
            </h2>
            <p className="text-xs text-[#857E78] font-medium mt-1 flex items-center gap-1.5">
              <Calendar size={13} className="text-[#C47366]" />
              <span>Jumat, 2 Oktober 2026</span>
              <span>·</span>
              <span className="text-[#7F998C]">19 Rabiul Akhir 1448 H</span>
            </p>
          </div>
          <button
            type="button"
            onClick={() => setIsProfileModalOpen(true)}
            className="text-[11px] font-medium text-[#C47366] hover:text-[#B35F52] bg-[#F8EDE9] hover:bg-[#F2DFD9] px-2.5 py-1 rounded-xl transition-colors shrink-0"
          >
            Atur Profil
          </button>
        </div>

        {profile.dailyNiat ? (
          <p className="text-xs text-[#6B645E] italic mt-2.5 bg-gradient-to-r from-[#F8EDE9]/80 to-[#FAF7F2] px-3.5 py-2 rounded-2xl border border-[#F1DDD7] block leading-relaxed">
            🌸 “{profile.dailyNiat}”
          </p>
        ) : (
          <p className="text-xs text-[#6A645F] italic mt-2 bg-[#F8EDE9]/60 px-3 py-1.5 rounded-xl border border-[#F1DDD7] inline-block">
            “Sedikit demi sedikit, menjadi lebih baik.”
          </p>
        )}
      </div>

      {/* 2. Card: Progress Hari Ini */}
      <section className="bg-white rounded-3xl p-5 border border-[#EFE8DF] shadow-[0_2px_12px_rgba(196,115,102,0.06)] relative overflow-hidden">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-[#F8EDE9] flex items-center justify-center text-[#C47366]">
              <Sparkles size={13} />
            </span>
            <h3 className="text-sm font-semibold text-[#2C2B2A]">
              Progress Hari Ini
            </h3>
          </div>
          <span className="text-sm font-bold text-[#C47366] tabular-nums">
            {progressPercentage}%
          </span>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-[#FAF7F2] h-2.5 rounded-full overflow-hidden my-3 border border-[#EFE8DF]/60">
          <div
            className="bg-gradient-to-r from-[#E5988B] to-[#C47366] h-full rounded-full transition-all duration-500 ease-out"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>

        <div className="flex items-center justify-between text-xs text-[#857E78]">
          <span className="tabular-nums font-medium text-[#504A45]">
            {completedTasksCount} dari {totalTasksCount} selesai
          </span>
          <span className="text-[11px] text-[#7F998C] font-medium">
            {getProgressEncouragement()}
          </span>
        </div>
      </section>

      {/* 3. Card Utama: Ada baiknya hari ini… */}
      <section className="bg-white rounded-3xl p-5 border border-[#EFE8DF] shadow-[0_2px_12px_rgba(196,115,102,0.06)]">
        <div className="flex items-center justify-between mb-3.5">
          <div>
            <h3 className="text-base font-semibold text-[#2C2B2A]">
              Ada baiknya hari ini…
            </h3>
            <p className="text-xs text-[#857E78] mt-0.5">
              Saran kecil dan positif untuk menemani harimu
            </p>
          </div>
          <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-[#F8EDE9] text-[#C47366] tabular-nums">
            {completedTasksCount}/{totalTasksCount}
          </span>
        </div>

        <div className="space-y-2">
          {tasks.map((task) => {
            return (
              <button
                key={task.id}
                type="button"
                onClick={() => toggleTask(task.id)}
                className={`w-full text-left flex items-center gap-3 p-3 rounded-2xl border transition-all duration-200 min-h-[48px] ${
                  task.completed
                    ? 'bg-[#FAF7F2]/80 border-[#E8DDD1] text-[#7D7670]'
                    : 'bg-white border-[#EFE8DF] hover:border-[#E0D3C4] text-[#2C2B2A]'
                }`}
              >
                {/* Custom Checkbox */}
                <div
                  className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 transition-all duration-200 ${
                    task.completed
                      ? 'bg-[#C47366] text-white shadow-xs'
                      : 'border-2 border-[#D8CFC5] bg-white hover:border-[#C47366]'
                  }`}
                >
                  {task.completed && <Check size={14} strokeWidth={2.8} />}
                </div>

                <span
                  className={`text-xs md:text-sm font-medium transition-all ${
                    task.completed ? 'line-through text-[#99928A]' : 'text-[#3D3935]'
                  }`}
                >
                  {task.text}
                </span>
              </button>
            );
          })}
        </div>

        <div className="mt-3.5 pt-3 border-t border-[#F5EFE9] flex items-center justify-between text-[11px] text-[#8C847E]">
          <span>🌿 Tidak perlu terburu-buru, nikmati setiap ikhtiar.</span>
          <button
            onClick={() => setActiveTab('quran')}
            className="text-[#C47366] hover:underline font-medium"
          >
            Lihat Ruang Qur'an →
          </button>
        </div>
      </section>

      {/* 4. Mood: Bagaimana perasaanmu hari ini? */}
      <section className="bg-white rounded-3xl p-5 border border-[#EFE8DF] shadow-[0_2px_12px_rgba(196,115,102,0.06)]">
        <h3 className="text-sm font-semibold text-[#2C2B2A] mb-1">
          Bagaimana perasaanmu hari ini?
        </h3>
        <p className="text-xs text-[#857E78] mb-3.5">
          Dengarkan hatimu, semua rasa itu valid dan layak diterima.
        </p>

        <div className="grid grid-cols-5 gap-2">
          {moods.map((m) => {
            const isSelected = mood === m.type;
            return (
              <button
                key={m.type}
                type="button"
                onClick={() => setMood(m.type)}
                className={`flex flex-col items-center justify-center p-2.5 rounded-2xl border transition-all duration-200 min-h-[64px] ${
                  isSelected
                    ? 'bg-[#F8EDE9] border-[#E8A598] text-[#C47366] shadow-xs scale-102 font-medium'
                    : 'bg-[#FAF7F2]/50 border-[#EFE8DF] text-[#6E6862] hover:bg-[#FAF7F2]'
                }`}
              >
                <span className="text-2xl mb-1">{m.emoji}</span>
                <span className="text-[10px] tracking-tight">{m.label}</span>
              </button>
            );
          })}
        </div>

        {mood && (
          <div className="mt-3 py-2 px-3 bg-[#FAF7F2] rounded-xl border border-[#EFE8DF] text-xs text-[#6B655F]">
            {mood === 'senang' && 'Alhamdulillah, semoga kebahagiaan ini membawa banyak kebaikan untuk sekitar 🌸'}
            {mood === 'baik' && 'Senang mendengarnya. Semoga harimu tetap teduh dan lancar ✨'}
            {mood === 'biasa' && 'Hari yang tenang juga sebuah anugerah. Nikmati ritmenya tanpa beban 🌿'}
            {mood === 'sedih' && 'Tidak apa-apa merasa sedih. Beri ruang pada hatimu, kamu tidak sendirian 💗'}
            {mood === 'lelah' && 'Istirahatlah sejenak. Tubuh dan pikiranmu sudah berjuang dengan baik hari ini 🕊️'}
          </div>
        )}
      </section>

      {/* 5. Card: 🌙 Refleksi Hari Ini */}
      <section className="bg-white rounded-3xl p-5 border border-[#EFE8DF] shadow-[0_2px_12px_rgba(196,115,102,0.06)]">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="text-lg">🌙</span>
            <h3 className="text-sm font-semibold text-[#2C2B2A]">
              Refleksi Hari Ini
            </h3>
          </div>
          {reflectionSavedStatus && (
            <span className="text-xs font-medium text-[#C47366] bg-[#F8EDE9] px-2.5 py-0.5 rounded-full animate-in fade-in duration-200">
              Refleksimu tersimpan 💗
            </span>
          )}
        </div>

        <form onSubmit={handleReflectionSubmit} className="space-y-3.5">
          <div>
            <label
              htmlFor="halBaikInput"
              className="block text-xs font-medium text-[#4A4541] mb-1.5"
            >
              Apa satu hal baik yang terjadi hari ini?
            </label>
            <textarea
              id="halBaikInput"
              rows={2}
              value={halBaik}
              onChange={(e) => setHalBaik(e.target.value)}
              placeholder="Tulis di sini…"
              className="w-full text-xs text-[#2C2B2A] p-3 rounded-2xl bg-[#FAF7F2] border border-[#EFE8DF] focus:outline-hidden focus:border-[#C47366] focus:bg-white transition-all placeholder:text-[#A09890] resize-none"
            />
          </div>

          <div>
            <label
              htmlFor="perbaikanBesokInput"
              className="block text-xs font-medium text-[#4A4541] mb-1.5"
            >
              Apa yang ingin aku perbaiki besok?
            </label>
            <textarea
              id="perbaikanBesokInput"
              rows={2}
              value={perbaikanBesok}
              onChange={(e) => setPerbaikanBesok(e.target.value)}
              placeholder="Tulis di sini…"
              className="w-full text-xs text-[#2C2B2A] p-3 rounded-2xl bg-[#FAF7F2] border border-[#EFE8DF] focus:outline-hidden focus:border-[#C47366] focus:bg-white transition-all placeholder:text-[#A09890] resize-none"
            />
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1">
            <p className="text-[11px] text-[#8C847E]">
              Refleksi membantumu mengenal diri dengan lebih bijak.
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleSaveAsJournal}
                className="px-3 py-2 min-h-[40px] rounded-xl bg-[#FAF7F2] border border-[#EFE8DF] hover:border-[#C47366] text-[#6E6862] hover:text-[#C47366] text-xs font-medium transition-all"
                title="Simpan sekaligus masukkan ke daftar Jurnal Refleksi"
              >
                + ke Jurnal 📖
              </button>
              <button
                type="submit"
                className="px-4 py-2 min-h-[40px] rounded-xl bg-[#C47366] text-white text-xs font-semibold hover:bg-[#B35F52] active:scale-98 transition-all shadow-xs"
              >
                Simpan Refleksi
              </button>
            </div>
          </div>
        </form>
      </section>

      {/* 6. Card: 💗 Aku Bersyukur Karena… */}
      <section className="bg-white rounded-3xl p-5 border border-[#EFE8DF] shadow-[0_2px_12px_rgba(196,115,102,0.06)]">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="text-base">💗</span>
            <h3 className="text-sm font-semibold text-[#2C2B2A]">
              Aku Bersyukur Karena…
            </h3>
          </div>
          {gratitudeSavedStatus && (
            <span className="text-xs font-medium text-[#7F998C] bg-[#EDF3F0] px-2.5 py-0.5 rounded-full animate-in fade-in duration-200">
              Tersimpan 🌸
            </span>
          )}
        </div>
        <p className="text-xs text-[#857E78] mb-3">
          Satu hal kecil yang patut disyukuri dari lubuk hati terdalam.
        </p>

        <form onSubmit={handleGratitudeSubmit} className="space-y-3">
          <textarea
            rows={2}
            value={gratitudeText}
            onChange={(e) => setGratitudeText(e.target.value)}
            placeholder="Tulis rasa syukurmu hari ini…"
            className="w-full text-xs text-[#2C2B2A] p-3 rounded-2xl bg-[#FAF7F2] border border-[#EFE8DF] focus:outline-hidden focus:border-[#C47366] focus:bg-white transition-all placeholder:text-[#A09890] resize-none"
          />

          <div className="flex justify-end">
            <button
              type="submit"
              className="px-4 py-2 min-h-[40px] rounded-xl bg-[#7F998C] text-white text-xs font-medium hover:bg-[#6E887B] active:scale-98 transition-all shadow-xs"
            >
              Simpan
            </button>
          </div>
        </form>
      </section>

      {/* 7. Card: 🌷 Ringkasan Pekan Ini */}
      <section className="bg-white rounded-3xl p-5 border border-[#EFE8DF] shadow-[0_2px_12px_rgba(196,115,102,0.06)]">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="text-base">🌷</span>
            <h3 className="text-sm font-semibold text-[#2C2B2A]">
              Ringkasan Pekan Ini
            </h3>
          </div>
          <span className="text-[11px] text-[#857E78] bg-[#FAF7F2] px-2.5 py-1 rounded-full border border-[#EFE8DF]">
            Pekan ke-1 Oktober
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          <div className="p-3 rounded-2xl bg-[#FAF7F2] border border-[#EFE8DF]">
            <p className="text-[11px] text-[#857E78] mb-0.5">Shalat Wajib</p>
            <p className="text-base font-bold text-[#2C2B2A] tabular-nums">
              {weeklySummary.shalatCompleted} / {weeklySummary.shalatTotal}
            </p>
            <p className="text-[10px] text-[#7F998C] mt-1">Konsistensi tinggi</p>
          </div>

          <div className="p-3 rounded-2xl bg-[#FAF7F2] border border-[#EFE8DF]">
            <p className="text-[11px] text-[#857E78] mb-0.5">Tilawah Qur’an</p>
            <p className="text-base font-bold text-[#2C2B2A] tabular-nums">
              {weeklySummary.tilawahPages} halaman
            </p>
            <p className="text-[10px] text-[#C47366] mt-1">Bertahap & istiqomah</p>
          </div>

          <div className="p-3 rounded-2xl bg-[#FAF7F2] border border-[#EFE8DF]">
            <p className="text-[11px] text-[#857E78] mb-0.5">Habit Selesai</p>
            <p className="text-base font-bold text-[#2C2B2A] tabular-nums">
              {weeklySummary.habitPercentage}%
            </p>
            <p className="text-[10px] text-[#7F998C] mt-1">Proses yang sehat</p>
          </div>

          <div className="p-3 rounded-2xl bg-[#FAF7F2] border border-[#EFE8DF]">
            <p className="text-[11px] text-[#857E78] mb-0.5">Refleksi & Jurnal</p>
            <p className="text-base font-bold text-[#2C2B2A] tabular-nums">
              {weeklySummary.journalDays} hari
            </p>
            <p className="text-[10px] text-[#857E78] mt-1">Mengenal isi hati</p>
          </div>
        </div>

        <div className="mt-3 p-3 rounded-2xl bg-[#F8EDE9]/60 border border-[#F1DDD7] flex items-center justify-between text-xs text-[#504A45]">
          <span className="flex items-center gap-1.5">
            <span>✨</span>
            <span>Kebaikan terbagi:</span>
          </span>
          <span className="font-bold text-[#C47366] tabular-nums">
            {weeklySummary.kebaikanCount} kali pekan ini
          </span>
        </div>
      </section>
    </div>
  );
};
