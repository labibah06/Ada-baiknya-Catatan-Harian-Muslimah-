import React from 'react';
import { useApp } from '../context/AppContext';
import { CatatanSubTab } from '../types';
import { TodayView } from './TodayView';
import { HabitView } from './HabitView';
import { JournalView } from './JournalView';
import { TargetView } from './TargetView';
import { Sparkles, CheckCircle2, Feather, Target } from 'lucide-react';

interface SubTabItem {
  id: CatatanSubTab;
  label: string;
  icon: React.ComponentType<{ className?: string; size?: number }>;
}

const subTabs: SubTabItem[] = [
  { id: 'hari-ini', label: 'Hari Ini', icon: Sparkles },
  { id: 'habit', label: 'Habit', icon: CheckCircle2 },
  { id: 'jurnal', label: 'Jurnal', icon: Feather },
  { id: 'target', label: 'Target', icon: Target },
];

export const RuangCatatanView: React.FC = () => {
  const { catatanSubTab, setCatatanSubTab } = useApp();

  return (
    <div className="space-y-4">
      {/* Sub Navigation Segmented Control */}
      <div className="bg-[#FAF7F2]/90 backdrop-blur-xs p-1 rounded-2xl border border-[#EFE8DF] sticky top-[57px] z-20 shadow-xs">
        <div className="grid grid-cols-4 gap-1">
          {subTabs.map((tab) => {
            const isActive = catatanSubTab === tab.id;
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setCatatanSubTab(tab.id)}
                className={`flex items-center justify-center gap-1.5 py-2 px-1 text-xs rounded-xl font-medium transition-all ${
                  isActive
                    ? 'bg-white text-[#C47366] shadow-xs font-semibold'
                    : 'text-[#7D7670] hover:text-[#2C2B2A] hover:bg-white/50'
                }`}
              >
                <Icon size={14} className={isActive ? 'text-[#C47366]' : 'text-[#8C847E]'} />
                <span className="truncate">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Sub-view Content */}
      <div>
        {catatanSubTab === 'hari-ini' && <TodayView />}
        {catatanSubTab === 'habit' && <HabitView />}
        {catatanSubTab === 'jurnal' && <JournalView />}
        {catatanSubTab === 'target' && <TargetView />}
      </div>
    </div>
  );
};
