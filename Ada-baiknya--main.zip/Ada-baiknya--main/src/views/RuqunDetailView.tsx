import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  ArrowLeft,
  MessageCircle,
  ZoomIn,
  X,
  Upload,
  Image as ImageIcon,
  CheckCircle2,
  Sparkles,
  RotateCcw,
} from 'lucide-react';
import { RuqunPamphlet } from '../types';
import {
  savePamphletImage,
  getPamphletImage,
  clearPamphletImage,
} from '../utils/pamphletStorage';
import { DigitalPamphlet } from '../components/DigitalPamphlet';

const ruqunPamphlets: RuqunPamphlet[] = [
  {
    id: 'pamflet-1',
    title: "Perubahan Nyata Setelah Belajar Al-Qur'an",
    subtitle: 'Bimbingan Ustazah Berpengalaman, Metode Terstruktur & Penuh Kasih',
    tag: 'Bimbingan & Metode',
    fileName: 'campaign_1.jpg',
  },
  {
    id: 'pamflet-2',
    title: "Kelas Privat Al-Qur'an",
    subtitle: 'Belajar 1 on 1, Lebih Fokus & Terarah (Tahsin, Tahfidz, Tilawah, Tajwid)',
    tag: 'Kelas Privat Online',
    fileName: 'Kelas Privat.jpg',
    altFileName: 'kelas_privat.jpg',
  },
  {
    id: 'pamflet-3',
    title: "Investasi Terbaik Bukan Gadget, Tapi Al-Qur'an",
    subtitle: 'Hadiahkan Anak Kelas Mengaji Online di RuQun Bersama Ustazah Terbaik',
    tag: 'Kelas Anak & Keluarga',
    fileName: 'campaign_6.jpg',
  },
  {
    id: 'pamflet-4',
    title: 'Perubahan Setelah Belajar di RuQun',
    subtitle: '1000+ Santri Telah Merasakan Perubahannya (Evaluasi & Pendampingan Personal)',
    tag: 'Hasil & Testimoni Santri',
    fileName: 'campaign_3.jpg',
  },
  {
    id: 'pamflet-5',
    title: "Pendaftaran Kelas Belajar Al-Qur'an",
    subtitle: 'Telah Diikuti +2500 Santri di Seluruh Indonesia (Kelas Tahsin & Tahfidz)',
    tag: 'Pendaftaran Program',
    fileName: 'Campaign kelas .jpg',
    altFileName: 'campaign_kelas.jpg',
  },
];

export const RuqunDetailView: React.FC = () => {
  const { setRuqunDetailOpen, showToast } = useApp();

  // Stored image URLs (either loaded from IndexedDB, file upload, or static path)
  const [customImages, setCustomImages] = useState<Record<string, string>>({});
  const [activeModalPamphlet, setActiveModalPamphlet] = useState<RuqunPamphlet | null>(null);
  const [isZoomed, setIsZoomed] = useState(false);

  // Hidden file inputs
  const fileInputRefs = useRef<Record<string, HTMLInputElement | null>>({});

  // WhatsApp Link
  const rawWaMessage =
    "Assalamu'alaikum. Saya melihat program RUQUN melalui aplikasi Ada Baiknya. Saya ingin mengetahui informasi program dan proses pendaftarannya. Mohon arahannya.";
  const waUrl = `https://wa.me/6285117130637?text=${encodeURIComponent(rawWaMessage)}`;

  // Check if an image is accessible from server
  const testImageSrc = (src: string): Promise<boolean> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => resolve(true);
      img.onerror = () => resolve(false);
      img.src = src;
    });
  };

  // Load saved images on mount (first check IndexedDB, then check server /pamflet/ folder)
  useEffect(() => {
    let isMounted = true;
    const loadImages = async () => {
      const loaded: Record<string, string> = {};
      for (const p of ruqunPamphlets) {
        const saved = await getPamphletImage(p.id);
        if (saved && isMounted) {
          loaded[p.id] = saved;
        } else {
          // Check if file is already on the server
          const serverSrc = `/pamflet/${encodeURIComponent(p.fileName)}`;
          const existsOnServer = await testImageSrc(serverSrc);
          if (existsOnServer && isMounted) {
            loaded[p.id] = serverSrc;
          } else if (p.altFileName) {
            const altServerSrc = `/pamflet/${p.altFileName}`;
            const altExists = await testImageSrc(altServerSrc);
            if (altExists && isMounted) {
              loaded[p.id] = altServerSrc;
            }
          }
        }
      }
      if (isMounted) {
        setCustomImages(loaded);
      }
    };
    loadImages();
    return () => {
      isMounted = false;
    };
  }, []);

  // Handle uploading image directly from user's phone / device
  const handleFileUpload = async (pamphletId: string, file: File) => {
    try {
      const pamphlet = ruqunPamphlets.find((item) => item.id === pamphletId);
      const reader = new FileReader();
      reader.onload = async (e) => {
        const dataUrl = e.target?.result as string;
        if (dataUrl) {
          // 1. Save locally to browser
          await savePamphletImage(pamphletId, dataUrl);
          setCustomImages((prev) => ({ ...prev, [pamphletId]: dataUrl }));
          showToast('Foto pamflet berhasil dipasang 🌸');

          // 2. Upload to server so other visitors on other phones also see it!
          if (pamphlet) {
            try {
              await fetch('/api/upload-pamflet', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  fileName: pamphlet.fileName,
                  altFileName: pamphlet.altFileName,
                  dataUrl,
                }),
              });
            } catch (err) {
              console.warn('Server upload notice:', err);
            }
          }
        }
      };
      reader.readAsDataURL(file);
    } catch {
      showToast('Gagal memuat gambar');
    }
  };

  const handleResetImage = async (pamphletId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    await clearPamphletImage(pamphletId);
    setCustomImages((prev) => {
      const next = { ...prev };
      delete next[pamphletId];
      return next;
    });
    showToast('Tampilan pamflet dikembalikan');
  };

  const openLightbox = (pamphlet: RuqunPamphlet) => {
    setActiveModalPamphlet(pamphlet);
    setIsZoomed(false);
  };

  const closeLightbox = () => {
    setActiveModalPamphlet(null);
    setIsZoomed(false);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* A. Header */}
      <section className="bg-white rounded-3xl p-5 border border-[#EFE8DF] shadow-[0_2px_12px_rgba(196,115,102,0.06)]">
        {/* Tombol Kembali ke Ruang Belajar */}
        <button
          type="button"
          onClick={() => setRuqunDetailOpen(false)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#FAF7F2] hover:bg-[#F3EBE3] text-xs font-medium text-[#6B645E] transition-colors mb-4"
        >
          <ArrowLeft size={14} />
          <span>Kembali ke Ruang Belajar</span>
        </button>

        <div className="flex items-start gap-3.5 mb-2">
          <div className="w-12 h-12 rounded-2xl bg-[#F8EDE9] flex items-center justify-center text-[#C47366] text-xl shrink-0 shadow-xs border border-[#F1DDD7]">
            🌸
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-[#2C2B2A] tracking-tight">
                RUQUN
              </h2>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#FDF8ED] text-[#A87B2E] border border-[#EADBB8]">
                Program Resmi
              </span>
            </div>
            <p className="text-xs text-[#C47366] font-medium">
              Rumah Qur'an Nur Hidayah
            </p>
          </div>
        </div>

        <p className="text-xs text-[#524C46] leading-relaxed pt-1 border-t border-[#F5EFE9]">
          Program pembelajaran Al-Qur'an online yang dirancang terstruktur, fleksibel, dan dibimbing oleh ustazah berpengalaman dengan penuh kasih. Tersedia bimbingan privat 1 on 1 dan kelas tahsin maupun tahfidz untuk muslimah dan keluarga.
        </p>
      </section>

      {/* B. Galeri Pamflet Program */}
      <section className="space-y-4">
        <div className="px-1 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-[#2C2B2A] flex items-center gap-2">
              <span>Galeri Pamflet Program</span>
              <span className="text-sm">📋</span>
            </h3>
            <p className="text-xs text-[#7F998C] font-medium mt-0.5">
              Pilih program yang sesuai dengan kebutuhanmu.
            </p>
          </div>
        </div>

        {/* Susunan Pamflet Secara Vertikal */}
        <div className="space-y-6">
          {ruqunPamphlets.map((pamphlet, index) => {
            const hasCustomImage = !!customImages[pamphlet.id];
            const customSrc = customImages[pamphlet.id];

            return (
              <div
                key={pamphlet.id}
                className="bg-white rounded-3xl p-4 sm:p-5 border border-[#EFE8DF] shadow-[0_2px_12px_rgba(196,115,102,0.06)] hover:border-[#DFD4C6] transition-all"
              >
                {/* Header Tiap Pamflet */}
                <div className="flex items-center justify-between mb-3 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#FAF7F2] text-[#8C847E] font-semibold text-[11px] flex items-center justify-center border border-[#EFE8DF]">
                      {index + 1}
                    </span>
                    <span className="text-[11px] font-semibold text-[#A87B2E] bg-[#FDF8ED] px-2.5 py-0.5 rounded-full border border-[#EADBB8]">
                      {pamphlet.tag}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Upload / Ganti Gambar dari Galeri HP */}
                    <label
                      htmlFor={`file-upload-${pamphlet.id}`}
                      className="cursor-pointer text-[11px] text-[#7F998C] hover:text-[#5B7869] font-medium flex items-center gap-1 bg-[#EDF3F0] hover:bg-[#E0ECE5] px-2.5 py-1 rounded-xl transition-colors"
                      title="Pasang foto pamflet asli dari galeri HP Anda"
                    >
                      <Upload size={12} />
                      <span>{hasCustomImage ? 'Ganti Foto' : 'Pasang Foto'}</span>
                    </label>
                    <input
                      id={`file-upload-${pamphlet.id}`}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          handleFileUpload(pamphlet.id, file);
                        }
                      }}
                      ref={(el) => {
                        fileInputRefs.current[pamphlet.id] = el;
                      }}
                    />

                    {hasCustomImage && (
                      <button
                        type="button"
                        onClick={(e) => handleResetImage(pamphlet.id, e)}
                        className="p-1 text-[#A89F96] hover:text-[#C47366] transition-colors"
                        title="Kembalikan tampilan"
                      >
                        <RotateCcw size={12} />
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => openLightbox(pamphlet)}
                      className="text-[11px] text-[#C47366] hover:text-[#B35F52] font-medium flex items-center gap-1"
                    >
                      <ZoomIn size={12} />
                      <span>Perbesar</span>
                    </button>
                  </div>
                </div>

                <h4 className="text-sm font-bold text-[#2C2B2A] mb-1">
                  {pamphlet.title}
                </h4>
                <p className="text-xs text-[#7A746E] leading-relaxed mb-3">
                  {pamphlet.subtitle}
                </p>

                {/* Wadah Tampilan Pamflet: Foto Asli ATAU Tampilan Pamflet Digital Resolusi Tinggi */}
                <div
                  onClick={() => openLightbox(pamphlet)}
                  className="cursor-pointer group relative rounded-2xl overflow-hidden border border-[#EFE8DF] transition-all hover:shadow-md"
                >
                  {hasCustomImage ? (
                    /* Display actual uploaded JPG */
                    <div className="relative bg-[#FAF7F2]">
                      <img
                        src={customSrc}
                        alt={`Pamflet Resmi RUQUN: ${pamphlet.title}`}
                        className="w-full h-auto object-contain block mx-auto max-h-[620px] rounded-2xl transition-transform duration-300 group-hover:scale-[1.01]"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center pointer-events-none">
                        <span className="opacity-0 group-hover:opacity-100 transition-opacity bg-white/95 text-[#2C2B2A] text-xs font-semibold px-3 py-1.5 rounded-full shadow-md flex items-center gap-1.5 backdrop-blur-xs">
                          <ZoomIn size={13} className="text-[#C47366]" />
                          <span>Ketuk untuk membaca detail</span>
                        </span>
                      </div>
                    </div>
                  ) : (
                    /* High-Fidelity Authentic Digital Pamphlet View */
                    <div className="relative">
                      <DigitalPamphlet id={pamphlet.id} />
                      {/* Hint overlay */}
                      <div className="absolute bottom-2 right-2 bg-white/90 backdrop-blur-xs px-2.5 py-1 rounded-xl border border-[#F8B4C8] shadow-xs flex items-center gap-1 text-[10px] text-[#C44D68] font-medium pointer-events-none">
                        <ZoomIn size={11} />
                        <span>Ketuk perbesar</span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="mt-2.5 flex items-center justify-between text-[11px] text-[#938B83]">
                  <span>🔍 Ketuk pamflet untuk membaca tulisan lebih besar</span>
                  <span className="text-[#7F998C] font-medium">Rumah Qur'an Nur Hidayah</span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* C & D. SATU Tombol WhatsApp untuk Semua Program & Keterangan Admin Marketing */}
      <section className="bg-white rounded-3xl p-6 border border-[#EFE8DF] shadow-[0_4px_24px_rgba(196,115,102,0.08)] text-center space-y-3">
        <div className="w-12 h-12 rounded-2xl bg-[#EDF3F0] text-[#7F998C] flex items-center justify-center mx-auto text-xl shadow-xs">
          💬
        </div>

        <div>
          <h4 className="text-sm font-bold text-[#2C2B2A]">
            Ingin Konsultasi & Mendaftar Kelas RUQUN?
          </h4>
          {/* D. Keterangan Admin Marketing */}
          <p className="text-xs text-[#7A746E] mt-1 leading-relaxed">
            Untuk informasi program dan pendaftaran, silakan hubungi admin marketing melalui WhatsApp.
          </p>
        </div>

        {/* C. HANYA SATU Tombol WhatsApp untuk Semua Program */}
        <div className="pt-2">
          <a
            href={waUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full min-h-[50px] py-3.5 px-6 rounded-2xl bg-[#25D366] hover:bg-[#20BE5B] text-white font-semibold text-sm flex items-center justify-center gap-2.5 shadow-[0_4px_16px_rgba(37,211,102,0.3)] active:scale-[0.98] transition-all"
          >
            <MessageCircle size={19} className="fill-white" />
            <span>Tanya & Daftar via WhatsApp</span>
          </a>
        </div>

        <p className="text-[11px] text-[#9C948D] pt-1">
          Pesan otomatis telah disiapkan agar admin marketing RUQUN dapat langsung menyambut dan mengarahkanmu.
        </p>
      </section>

      {/* Lightbox / Modal Perbesar Pamflet */}
      {activeModalPamphlet && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={closeLightbox}
        >
          <div
            className="bg-white rounded-3xl max-w-lg w-full max-h-[92vh] flex flex-col shadow-2xl relative overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="p-4 border-b border-[#F0EAE1] flex items-center justify-between bg-[#FAF7F2]">
              <div className="truncate pr-2">
                <p className="text-[11px] font-semibold text-[#A87B2E]">
                  {activeModalPamphlet.tag} · RUQUN
                </p>
                <h4 className="text-sm font-bold text-[#2C2B2A] truncate">
                  {activeModalPamphlet.title}
                </h4>
              </div>
              <button
                type="button"
                onClick={closeLightbox}
                className="w-8 h-8 rounded-full bg-white border border-[#EFE8DF] flex items-center justify-center text-[#7A746E] hover:bg-[#FAF7F2] shrink-0"
                aria-label="Tutup"
              >
                <X size={16} />
              </button>
            </div>

            {/* Modal Body / Scrollable View */}
            <div className="overflow-y-auto p-4 flex-1 flex flex-col items-center justify-center bg-[#FAF7F2]">
              {customImages[activeModalPamphlet.id] ? (
                <img
                  src={customImages[activeModalPamphlet.id]}
                  alt={activeModalPamphlet.title}
                  className={`w-full h-auto object-contain max-h-[75vh] rounded-xl transition-all duration-300 ${
                    isZoomed ? 'scale-125 cursor-zoom-out' : 'cursor-zoom-in'
                  }`}
                  onClick={() => setIsZoomed(!isZoomed)}
                />
              ) : (
                <div
                  className={`w-full transition-all duration-300 ${
                    isZoomed ? 'scale-105' : ''
                  }`}
                >
                  <DigitalPamphlet id={activeModalPamphlet.id} />
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-3 border-t border-[#F0EAE1] flex items-center justify-between text-xs bg-[#FAF7F2]">
              <span className="text-[11px] text-[#7A746E]">
                Rumah Qur'an Nur Hidayah
              </span>
              <button
                type="button"
                onClick={closeLightbox}
                className="px-4 py-1.5 rounded-xl bg-[#C47366] text-white text-xs font-medium hover:bg-[#B35F52]"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
