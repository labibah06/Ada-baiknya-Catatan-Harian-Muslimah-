import React from 'react';
import { useApp } from '../context/AppContext';
import {
  GraduationCap,
  BookOpen,
  ArrowRight,
  Sparkles,
  Users,
  Video,
  Heart,
  Check,
} from 'lucide-react';

export const RuangBelajarView: React.FC = () => {
  const { setRuqunDetailOpen } = useApp();

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="pt-2 px-1">
        <h2 className="text-2xl font-bold tracking-tight text-[#2C2B2A] flex items-center gap-2">
          <span>Ruang Belajar</span>
          <span className="text-xl">🌿</span>
        </h2>
        <p className="text-xs text-[#857E78] mt-1">
          Katalog program belajar Al-Qur'an dan pengembangan diri untuk Muslimah.
        </p>
      </div>

      {/* Program Utama: RUQUN — Rumah Qur'an Nur Hidayah */}
      <section className="bg-white rounded-3xl p-6 border border-[#EFE8DF] shadow-[0_4px_20px_rgba(196,115,102,0.06)] relative overflow-hidden">
        {/* Subtle decorative gold-rose background aura */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-[#F6E5E3] via-[#FAF1E3]/50 to-transparent rounded-bl-full pointer-events-none -z-0" />

        <div className="relative z-10">
          {/* Badge */}
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FDF8ED] border border-[#EADBB8] text-[11px] font-semibold text-[#A87B2E] mb-3">
            <Sparkles size={12} className="text-[#C5A059]" />
            <span>Program Rekomendasi Muslimah</span>
          </div>

          {/* Program Title & Brand */}
          <div className="flex items-start gap-3.5 mb-3">
            <div className="w-12 h-12 rounded-2xl bg-[#F8EDE9] flex items-center justify-center text-[#C47366] text-xl shrink-0 shadow-xs">
              📖
            </div>
            <div>
              <h3 className="text-lg font-bold text-[#2C2B2A] leading-snug">
                RUQUN
              </h3>
              <p className="text-xs text-[#C47366] font-medium">
                Rumah Qur'an Nur Hidayah
              </p>
            </div>
          </div>

          {/* Official Description */}
          <p className="text-xs text-[#524C46] leading-relaxed mb-4">
            Temukan program belajar Al-Qur'an dari Rumah Qur'an Nur Hidayah. Jelajahi informasi program yang tersedia dan hubungi admin marketing untuk mengetahui detail serta proses pendaftaran.
          </p>

          {/* Highlight Points */}
          <div className="grid grid-cols-2 gap-2 mb-5">
            <div className="p-2.5 rounded-2xl bg-[#FAF7F2] border border-[#EFE8DF] flex items-start gap-2">
              <span className="w-5 h-5 rounded-full bg-[#EDF3F0] text-[#7F998C] flex items-center justify-center shrink-0 mt-0.5">
                <Check size={11} strokeWidth={3} />
              </span>
              <span className="text-[11px] text-[#4A4541] font-medium">
                Bimbingan Ustazah Penuh Kasih
              </span>
            </div>
            <div className="p-2.5 rounded-2xl bg-[#FAF7F2] border border-[#EFE8DF] flex items-start gap-2">
              <span className="w-5 h-5 rounded-full bg-[#EDF3F0] text-[#7F998C] flex items-center justify-center shrink-0 mt-0.5">
                <Check size={11} strokeWidth={3} />
              </span>
              <span className="text-[11px] text-[#4A4541] font-medium">
                Kelas Privat 1 on 1 & Reguler
              </span>
            </div>
            <div className="p-2.5 rounded-2xl bg-[#FAF7F2] border border-[#EFE8DF] flex items-start gap-2">
              <span className="w-5 h-5 rounded-full bg-[#EDF3F0] text-[#7F998C] flex items-center justify-center shrink-0 mt-0.5">
                <Check size={11} strokeWidth={3} />
              </span>
              <span className="text-[11px] text-[#4A4541] font-medium">
                Online Fleksibel dari Rumah
              </span>
            </div>
            <div className="p-2.5 rounded-2xl bg-[#FAF7F2] border border-[#EFE8DF] flex items-start gap-2">
              <span className="w-5 h-5 rounded-full bg-[#EDF3F0] text-[#7F998C] flex items-center justify-center shrink-0 mt-0.5">
                <Check size={11} strokeWidth={3} />
              </span>
              <span className="text-[11px] text-[#4A4541] font-medium">
                Tahsin, Tahfidz, Tajwid
              </span>
            </div>
          </div>

          {/* CTA: Lihat Program RUQUN */}
          <button
            type="button"
            onClick={() => setRuqunDetailOpen(true)}
            className="w-full py-3.5 px-4 rounded-2xl bg-[#C47366] hover:bg-[#B35F52] text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-[0_4px_12px_rgba(196,115,102,0.25)] active:scale-[0.98] transition-all"
          >
            <span>Lihat Program RUQUN</span>
            <ArrowRight size={15} />
          </button>
        </div>
      </section>

      {/* Gentle Motivation Card */}
      <div className="p-4 rounded-3xl bg-[#FAF7F2] border border-[#EFE8DF] text-xs text-[#6B645E] leading-relaxed text-center">
        🌸 <em>“Belajar Al-Qur'an bukan tentang seberapa cepat, tapi tentang seberapa istiqamah kamu melangkah.”</em>
        <p className="text-[11px] text-[#938B83] mt-1">
          Semoga setiap huruf yang dipelajari menjadi cahaya yang menenangkan hati.
        </p>
      </div>
    </div>
  );
};
