import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Plus,
  Trash2,
  Edit3,
  X,
  BookOpen,
  Calendar,
  Smile,
  ChevronRight,
  Sparkles,
  Shuffle,
  PenLine,
  Heart,
} from 'lucide-react';
import { JournalEntry, MoodType } from '../types';

const moodEmojiMap: Record<MoodType, string> = {
  senang: '😊 Senang',
  baik: '🙂 Baik',
  biasa: '😐 Biasa saja',
  sedih: '😔 Sedih',
  lelah: '😴 Lelah',
};

// Curated daily reflection prompts for Muslimah
const dailyPrompts = [
  {
    title: 'Hal Baik Hari Ini',
    prompt: 'Apa hal baik yang terjadi hari ini?',
    starter: 'Hal baik yang terjadi hari ini dan membuat hatiku bersyukur adalah: ',
    icon: '🌷',
  },
  {
    title: 'Momen Ketenangan',
    prompt: 'Momen apa yang membuat hatimu merasa paling tenang hari ini?',
    starter: 'Momen paling tenang yang aku rasakan hari ini adalah saat: ',
    icon: '🕊️',
  },
  {
    title: 'Hikmah & Pelajaran',
    prompt: 'Apa satu pelajaran atau hikmah berharga yang kamu petik hari ini?',
    starter: 'Pelajaran berharga yang Allah ajarkan kepadaku hari ini adalah: ',
    icon: '📖',
  },
  {
    title: 'Doa & Terima Kasih',
    prompt: 'Siapa sosok yang ingin kamu doakan atau ucapkan terima kasih hari ini?',
    starter: 'Hari ini aku teringat dan ingin mendoakan kebaikan untuk: ',
    icon: '🤲',
  },
  {
    title: 'Melepaskan Beban',
    prompt: 'Apa satu kekhawatiran yang ingin kamu pasrahkan sepenuhnya kepada Allah?',
    starter: 'Satu hal yang sempat membebani pikiranku dan ingin kupasrahkan adalah: ',
    icon: '🤍',
  },
  {
    title: 'Langkah Perbaikan',
    prompt: 'Apa satu hal kecil yang ingin kamu perbaiki dengan lembut esok hari?',
    starter: 'Besok, insyaAllah aku ingin melangkah lebih baik dalam hal: ',
    icon: '🌱',
  },
];

export const JournalView: React.FC = () => {
  const { journals, addJournal, updateJournal, deleteJournal, showToast } = useApp();

  // Active prompt index for the daily inspiration card
  const [currentPromptIndex, setCurrentPromptIndex] = useState(0);

  // State for Create / Edit Modal
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [titleInput, setTitleInput] = useState('');
  const [contentInput, setContentInput] = useState('');
  const [moodInput, setMoodInput] = useState<MoodType>('senang');
  const [selectedPromptText, setSelectedPromptText] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState('');

  // State for Read Modal
  const [activeReadingEntry, setActiveReadingEntry] = useState<JournalEntry | null>(null);

  const activeDailyPrompt = dailyPrompts[currentPromptIndex];

  // Rotate to another random prompt
  const handleShufflePrompt = () => {
    setCurrentPromptIndex((prev) => (prev + 1) % dailyPrompts.length);
    showToast('Prompt refleksi diganti ✨');
  };

  // Open form with a selected reflection prompt
  const openFormWithPrompt = (promptItem: typeof dailyPrompts[0]) => {
    setEditingId(null);
    setTitleInput(promptItem.prompt);
    setContentInput(promptItem.starter);
    setSelectedPromptText(promptItem.prompt);
    setMoodInput('baik');
    setErrorMessage('');
    setIsFormOpen(true);
  };

  const openNewForm = () => {
    setEditingId(null);
    setTitleInput('');
    setContentInput('');
    setSelectedPromptText(null);
    setMoodInput('senang');
    setErrorMessage('');
    setIsFormOpen(true);
  };

  const openEditForm = (entry: JournalEntry) => {
    setEditingId(entry.id);
    setTitleInput(entry.title);
    setContentInput(entry.content);
    setSelectedPromptText(null);
    setMoodInput(entry.mood);
    setErrorMessage('');
    setActiveReadingEntry(null);
    setIsFormOpen(true);
  };

  const handleApplyPromptInModal = (promptItem: typeof dailyPrompts[0]) => {
    if (!titleInput.trim()) {
      setTitleInput(promptItem.prompt);
    }
    setContentInput((prev) =>
      prev.trim() ? `${prev}\n\n[Refleksi: ${promptItem.prompt}]\n${promptItem.starter}` : promptItem.starter
    );
    setSelectedPromptText(promptItem.prompt);
    showToast('Prompt ditambahkan ke tulisan 🌸');
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!titleInput.trim()) {
      setErrorMessage('Silakan isi judul jurnal terlebih dahulu 🌸');
      return;
    }
    if (!contentInput.trim()) {
      setErrorMessage('Tuliskan sedikit curahan hatimu terlebih dahulu ✨');
      return;
    }

    const todayDateFormatted = new Intl.DateTimeFormat('id-ID', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }).format(new Date());

    if (editingId) {
      updateJournal(editingId, {
        title: titleInput.trim(),
        content: contentInput.trim(),
        mood: moodInput,
      });
    } else {
      addJournal({
        title: titleInput.trim(),
        content: contentInput.trim(),
        mood: moodInput,
        date: todayDateFormatted,
      });
    }

    setIsFormOpen(false);
  };

  const handleDelete = (id: string) => {
    if (activeReadingEntry?.id === id) {
      setActiveReadingEntry(null);
    }
    deleteJournal(id);
  };

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="pt-2 px-1">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-[#2C2B2A]">
              Jurnal Refleksi
            </h2>
            <p className="text-xs text-[#857E78] mt-1">
              “Tempat kecil untuk menuangkan isi hati dan pikiran.”
            </p>
          </div>
          <button
            onClick={openNewForm}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#C47366] text-white text-xs font-semibold hover:bg-[#B35F52] active:scale-95 transition-all shadow-xs shrink-0"
          >
            <Plus size={15} />
            <span>Tulis</span>
          </button>
        </div>
      </div>

      {/* FITUR BARU: Kartu Prompt Refleksi Harian Interaktif */}
      <section className="bg-gradient-to-br from-[#FFF5F3] via-[#FAF1ED] to-[#F5ECE8] rounded-3xl p-5 border border-[#F1DDD7] shadow-[0_4px_16px_rgba(196,115,102,0.08)] relative overflow-hidden text-left">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2">
            <span className="w-7 h-7 rounded-full bg-white flex items-center justify-center text-sm shadow-xs border border-[#F1DDD7]">
              {activeDailyPrompt.icon}
            </span>
            <div>
              <span className="text-[10px] font-bold text-[#C47366] uppercase tracking-wider block">
                Prompt Refleksi Hari Ini
              </span>
              <h3 className="text-xs font-bold text-[#2C2B2A]">
                {activeDailyPrompt.title}
              </h3>
            </div>
          </div>

          <button
            type="button"
            onClick={handleShufflePrompt}
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-white/80 hover:bg-white text-[11px] font-medium text-[#7D7670] border border-[#EFE8DF] transition-colors"
            title="Ganti prompt inspirasi lain"
          >
            <Shuffle size={12} className="text-[#C47366]" />
            <span>Ganti</span>
          </button>
        </div>

        {/* Big Question Quote */}
        <p className="text-sm font-semibold text-[#2C2B2A] leading-snug my-2 bg-white/70 p-3 rounded-2xl border border-[#F1DDD7]/80">
          “{activeDailyPrompt.prompt}”
        </p>

        <div className="flex items-center justify-between mt-3 pt-2 border-t border-[#F1DDD7]/60">
          <p className="text-[11px] text-[#7A746E]">
            Gunakan pertanyaan ini untuk membantumu mulai menulis.
          </p>
          <button
            type="button"
            onClick={() => openFormWithPrompt(activeDailyPrompt)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#C47366] hover:bg-[#B35F52] text-white text-xs font-semibold shadow-xs active:scale-95 transition-all"
          >
            <PenLine size={13} />
            <span>Tulis Refleksi Ini</span>
          </button>
        </div>

        {/* Quick Horizontal Prompt Chips */}
        <div className="mt-3 pt-3 border-t border-[#F1DDD7]/60">
          <span className="text-[10px] font-medium text-[#8C847E] block mb-1.5">
            Pilihan prompt lainnya:
          </span>
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
            {dailyPrompts.map((item, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => openFormWithPrompt(item)}
                className={`text-[11px] font-medium px-2.5 py-1 rounded-xl border whitespace-nowrap transition-all flex items-center gap-1 shrink-0 ${
                  currentPromptIndex === idx
                    ? 'bg-white text-[#C47366] border-[#E8A598] shadow-xs'
                    : 'bg-white/60 hover:bg-white text-[#6E6862] border-[#EFE8DF]'
                }`}
              >
                <span>{item.icon}</span>
                <span>{item.title}</span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Gentle Quote Card */}
      <div className="p-3.5 rounded-2xl bg-white border border-[#EFE8DF] text-xs text-[#504A45] leading-relaxed flex items-center gap-2">
        <span className="text-sm">🌿</span>
        <span><em>Menulis adalah cara lembut berbicara dengan diri sendiri dan merenungi nikmat-Nya tanpa distraksi.</em></span>
      </div>

      {/* Journal List */}
      <div className="space-y-3">
        {journals.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-3xl border border-[#EFE8DF]">
            <p className="text-sm font-medium text-[#4A4541] mb-1">
              Belum ada tulisan jurnal
            </p>
            <p className="text-xs text-[#857E78] mb-4">
              Mulai goreskan cerita, doa, atau renungan hari ini dengan bantuan prompt di atas.
            </p>
            <button
              onClick={() => openFormWithPrompt(dailyPrompts[0])}
              className="px-4 py-2 rounded-xl bg-[#C47366] text-white text-xs font-medium hover:bg-[#B35F52]"
            >
              + Tulis Refleksi Pertama
            </button>
          </div>
        ) : (
          journals.map((entry) => (
            <article
              key={entry.id}
              onClick={() => setActiveReadingEntry(entry)}
              className="p-5 rounded-3xl bg-white border border-[#EFE8DF] shadow-[0_2px_12px_rgba(196,115,102,0.04)] hover:border-[#DFD4C6] transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between text-xs text-[#857E78] mb-2">
                <span className="flex items-center gap-1.5 text-[11px]">
                  <Calendar size={12} className="text-[#C47366]" />
                  <span>{entry.date}</span>
                </span>
                <span className="text-[11px] text-[#C47366] font-medium bg-[#F8EDE9] px-2 py-0.5 rounded-full">
                  {moodEmojiMap[entry.mood]}
                </span>
              </div>

              <h3 className="text-base font-semibold text-[#2C2B2A] mb-1.5 group-hover:text-[#C47366] transition-colors">
                {entry.title}
              </h3>

              <p className="text-xs text-[#6B655F] line-clamp-2 leading-relaxed">
                {entry.content}
              </p>

              <div className="mt-3 pt-3 border-t border-[#F5EFE9] flex items-center justify-between text-[11px] text-[#A0978E]">
                <span>Ketuk untuk membaca selengkapnya</span>
                <ChevronRight size={14} className="text-[#C47366]" />
              </div>
            </article>
          ))
        )}
      </div>

      {/* Reader Modal */}
      {activeReadingEntry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-xl relative border border-[#EFE8DF] max-h-[85vh] flex flex-col text-left">
            <div className="flex items-center justify-between pb-3 border-b border-[#F0EAE1]">
              <div className="flex items-center gap-2 text-xs text-[#857E78]">
                <span>{activeReadingEntry.date}</span>
                <span>·</span>
                <span className="text-[#C47366] font-medium">
                  {moodEmojiMap[activeReadingEntry.mood]}
                </span>
              </div>
              <button
                onClick={() => setActiveReadingEntry(null)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-[#857E78] hover:bg-[#FAF7F2]"
              >
                <X size={18} />
              </button>
            </div>

            <div className="overflow-y-auto py-4 flex-1">
              <h3 className="text-lg font-bold text-[#2C2B2A] mb-3">
                {activeReadingEntry.title}
              </h3>
              <p className="text-xs text-[#4A4541] leading-relaxed whitespace-pre-wrap">
                {activeReadingEntry.content}
              </p>
            </div>

            <div className="pt-3 border-t border-[#F0EAE1] flex items-center justify-between">
              <button
                onClick={() => handleDelete(activeReadingEntry.id)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-[#C47366] hover:bg-[#FCECE9] transition-colors"
              >
                <Trash2 size={14} />
                <span>Hapus</span>
              </button>

              <button
                onClick={() => openEditForm(activeReadingEntry)}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#FAF7F2] border border-[#EFE8DF] text-xs font-medium text-[#4A4541] hover:bg-[#F0EAE1] transition-colors"
              >
                <Edit3 size={14} />
                <span>Edit Jurnal</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Write / Edit Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-xl relative border border-[#EFE8DF] max-h-[92vh] overflow-y-auto text-left">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-base font-semibold text-[#2C2B2A]">
                  {editingId ? 'Edit Jurnal' : 'Tulis Jurnal Refleksi'}
                </h3>
                <p className="text-[11px] text-[#8C847E]">
                  Tuliskan dengan santai dan jujur kepada dirimu sendiri.
                </p>
              </div>
              <button
                onClick={() => setIsFormOpen(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-[#857E78] hover:bg-[#FAF7F2]"
              >
                <X size={18} />
              </button>
            </div>

            {/* Prompt Helper Selector in Modal */}
            {!editingId && (
              <div className="mb-3.5 p-3 rounded-2xl bg-[#FAF7F2] border border-[#EFE8DF]">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] font-semibold text-[#5C5651] flex items-center gap-1">
                    <Sparkles size={12} className="text-[#C47366]" />
                    <span>Inspirasi Prompt:</span>
                  </span>
                  <span className="text-[10px] text-[#8C847E]">Ketuk untuk gunakan</span>
                </div>
                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
                  {dailyPrompts.map((p, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleApplyPromptInModal(p)}
                      className="px-2.5 py-1 text-[10px] rounded-lg bg-white border border-[#E2D8CC] text-[#4A4541] hover:border-[#C47366] hover:text-[#C47366] whitespace-nowrap transition-colors"
                    >
                      {p.icon} {p.title}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {errorMessage && (
              <div className="mb-3 p-2.5 rounded-xl bg-[#FCECE9] text-xs text-[#C47366]">
                {errorMessage}
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-[#4A4541] mb-1.5">
                  Judul Jurnal / Pertanyaan Refleksi
                </label>
                <input
                  type="text"
                  value={titleInput}
                  onChange={(e) => setTitleInput(e.target.value)}
                  placeholder="Contoh: Apa hal baik yang terjadi hari ini?…"
                  className="w-full text-xs text-[#2C2B2A] p-3 rounded-xl bg-[#FAF7F2] border border-[#EFE8DF] focus:outline-hidden focus:border-[#C47366] focus:bg-white transition-all placeholder:text-[#A09890]"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#4A4541] mb-1.5">
                  Suasana Hati (Mood)
                </label>
                <div className="grid grid-cols-5 gap-1.5">
                  {(['senang', 'baik', 'biasa', 'sedih', 'lelah'] as MoodType[]).map(
                    (m) => (
                      <button
                        key={m}
                        type="button"
                        onClick={() => setMoodInput(m)}
                        className={`p-2 text-xs rounded-xl border text-center transition-all ${
                          moodInput === m
                            ? 'bg-[#F8EDE9] border-[#E8A598] text-[#C47366] font-medium'
                            : 'bg-[#FAF7F2] border-[#EFE8DF] text-[#6E6862]'
                        }`}
                      >
                        <span className="block text-sm mb-0.5">{moodEmojiMap[m].split(' ')[0]}</span>
                        <span className="text-[10px] block truncate">{moodEmojiMap[m].split(' ')[1]}</span>
                      </button>
                    )
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#4A4541] mb-1.5">
                  Isi Refleksi
                </label>
                <textarea
                  rows={6}
                  value={contentInput}
                  onChange={(e) => setContentInput(e.target.value)}
                  placeholder="Tuangkan apa yang kamu rasakan hari ini tanpa takut dinilai…"
                  className="w-full text-xs text-[#2C2B2A] p-3 rounded-xl bg-[#FAF7F2] border border-[#EFE8DF] focus:outline-hidden focus:border-[#C47366] focus:bg-white transition-all placeholder:text-[#A09890] resize-none leading-relaxed"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-[#EFE8DF] text-xs font-medium text-[#6E6862] hover:bg-[#FAF7F2]"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#C47366] text-white text-xs font-semibold hover:bg-[#B35F52] shadow-xs"
                >
                  Simpan Jurnal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
