import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Target,
  Plus,
  Trash2,
  Edit3,
  X,
  CheckCircle2,
  Clock,
  Sparkles,
  ChevronDown,
} from 'lucide-react';
import { TargetCategory, TargetItem } from '../types';

const categoryLabels: Record<TargetCategory, { label: string; icon: string; color: string }> = {
  personal: { label: 'Target Pribadi', icon: '🌱', color: '#7F998C' },
  ibadah: { label: 'Target Ibadah', icon: '🕌', color: '#C47366' },
  productivity: { label: 'Target Produktivitas', icon: '💼', color: '#D4A373' },
};

export const TargetView: React.FC = () => {
  const { targets, addTarget, updateTarget, deleteTarget, showToast } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTargetId, setEditingTargetId] = useState<string | null>(null);

  // Form states
  const [nameInput, setNameInput] = useState('');
  const [categoryInput, setCategoryInput] = useState<TargetCategory>('personal');
  const [deadlineInput, setDeadlineInput] = useState('');
  const [progressInput, setProgressInput] = useState<number>(0);
  const [notesInput, setNotesInput] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const openAddModal = () => {
    setEditingTargetId(null);
    setNameInput('');
    setCategoryInput('personal');
    setDeadlineInput('Akhir Bulan');
    setProgressInput(10);
    setNotesInput('');
    setErrorMessage('');
    setIsModalOpen(true);
  };

  const openEditModal = (item: TargetItem) => {
    setEditingTargetId(item.id);
    setNameInput(item.name);
    setCategoryInput(item.category);
    setDeadlineInput(item.deadline);
    setProgressInput(item.progress);
    setNotesInput(item.notes || '');
    setErrorMessage('');
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim()) {
      setErrorMessage('Silakan isi nama target terlebih dahulu 🌸');
      return;
    }

    if (editingTargetId) {
      updateTarget(editingTargetId, {
        name: nameInput.trim(),
        category: categoryInput,
        deadline: deadlineInput.trim() || 'Bertahap',
        progress: Number(progressInput),
        notes: notesInput.trim(),
        status: Number(progressInput) >= 100 ? 'completed' : 'ongoing',
      });
    } else {
      addTarget({
        name: nameInput.trim(),
        category: categoryInput,
        deadline: deadlineInput.trim() || 'Bertahap',
        progress: Number(progressInput),
        notes: notesInput.trim(),
        status: Number(progressInput) >= 100 ? 'completed' : 'ongoing',
      });
    }

    setIsModalOpen(false);
  };

  const adjustProgress = (id: string, delta: number) => {
    const target = targets.find((t) => t.id === id);
    if (!target) return;
    const nextProgress = Math.min(100, Math.max(0, target.progress + delta));
    updateTarget(id, {
      progress: nextProgress,
      status: nextProgress >= 100 ? 'completed' : 'ongoing',
    });
  };

  const filteredTargets =
    selectedCategory === 'all'
      ? targets
      : targets.filter((t) => t.category === selectedCategory);

  const completedTargetsCount = targets.filter((t) => t.progress >= 100).length;

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-300">
      {/* Title & Subtitle */}
      <div className="pt-2 px-1">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-[#2C2B2A] flex items-center gap-2">
              <span>Targetku</span>
              <span>🎯</span>
            </h2>
            <p className="text-xs text-[#857E78] mt-1">
              “Tidak harus langsung besar. Yang penting mulai.”
            </p>
          </div>
          <button
            onClick={openAddModal}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#C47366] text-white text-xs font-medium hover:bg-[#B35F52] active:scale-95 transition-all shadow-xs shrink-0"
          >
            <Plus size={15} />
            <span>Target</span>
          </button>
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-[#F2ECE4] rounded-2xl overflow-x-auto no-scrollbar">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`px-3 py-1.5 text-xs font-medium rounded-xl whitespace-nowrap transition-all ${
            selectedCategory === 'all'
              ? 'bg-white text-[#2C2B2A] shadow-xs'
              : 'text-[#6E6862] hover:text-[#2C2B2A]'
          }`}
        >
          Semua ({targets.length})
        </button>
        <button
          onClick={() => setSelectedCategory('personal')}
          className={`px-3 py-1.5 text-xs font-medium rounded-xl whitespace-nowrap transition-all ${
            selectedCategory === 'personal'
              ? 'bg-white text-[#2C2B2A] shadow-xs'
              : 'text-[#6E6862] hover:text-[#2C2B2A]'
          }`}
        >
          🌱 Pribadi
        </button>
        <button
          onClick={() => setSelectedCategory('ibadah')}
          className={`px-3 py-1.5 text-xs font-medium rounded-xl whitespace-nowrap transition-all ${
            selectedCategory === 'ibadah'
              ? 'bg-white text-[#2C2B2A] shadow-xs'
              : 'text-[#6E6862] hover:text-[#2C2B2A]'
          }`}
        >
          🕌 Ibadah
        </button>
        <button
          onClick={() => setSelectedCategory('productivity')}
          className={`px-3 py-1.5 text-xs font-medium rounded-xl whitespace-nowrap transition-all ${
            selectedCategory === 'productivity'
              ? 'bg-white text-[#2C2B2A] shadow-xs'
              : 'text-[#6E6862] hover:text-[#2C2B2A]'
          }`}
        >
          💼 Produktivitas
        </button>
      </div>

      {/* Target Items List */}
      <div className="space-y-3.5">
        {filteredTargets.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-3xl border border-[#EFE8DF]">
            <p className="text-sm font-medium text-[#4A4541] mb-1">
              Belum ada target pada kategori ini
            </p>
            <p className="text-xs text-[#857E78] mb-4">
              Mulai dengan satu hal kecil yang ingin kamu capai.
            </p>
            <button
              onClick={openAddModal}
              className="px-4 py-2 rounded-xl bg-[#C47366] text-white text-xs font-medium hover:bg-[#B35F52]"
            >
              + Tambah Target Baru
            </button>
          </div>
        ) : (
          filteredTargets.map((item) => {
            const cat = categoryLabels[item.category];
            const isFinished = item.progress >= 100;

            return (
              <div
                key={item.id}
                className="p-5 rounded-3xl bg-white border border-[#EFE8DF] shadow-[0_2px_12px_rgba(196,115,102,0.04)] relative"
              >
                {/* Header row: Category & Deadline */}
                <div className="flex items-center justify-between text-xs text-[#857E78] mb-2">
                  <div className="flex items-center gap-1.5">
                    <span>{cat.icon}</span>
                    <span className="font-medium text-[#5A544E]">{cat.label}</span>
                  </div>
                  <span className="flex items-center gap-1 text-[11px] text-[#8C847E]">
                    <Clock size={11} />
                    <span>{item.deadline}</span>
                  </span>
                </div>

                {/* Target Name */}
                <h3
                  className={`text-base font-semibold mb-2 ${
                    isFinished ? 'text-[#3E5C4E]' : 'text-[#2C2B2A]'
                  }`}
                >
                  {item.name}
                </h3>

                {item.notes && (
                  <p className="text-xs text-[#736C65] mb-3 leading-relaxed">
                    {item.notes}
                  </p>
                )}

                {/* Progress bar and % */}
                <div className="space-y-1.5 my-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[#857E78] font-medium">Progress</span>
                    <span
                      className={`font-bold tabular-nums ${
                        isFinished ? 'text-[#7F998C]' : 'text-[#C47366]'
                      }`}
                    >
                      {item.progress}%
                    </span>
                  </div>

                  <div className="w-full bg-[#FAF7F2] h-2.5 rounded-full overflow-hidden border border-[#EFE8DF]/60">
                    <div
                      className={`h-full rounded-full transition-all duration-400 ease-out ${
                        isFinished
                          ? 'bg-[#7F998C]'
                          : 'bg-gradient-to-r from-[#E5988B] to-[#C47366]'
                      }`}
                      style={{ width: `${item.progress}%` }}
                    />
                  </div>
                </div>

                {/* Quick adjustments & actions */}
                <div className="flex items-center justify-between pt-2 border-t border-[#F5EFE9] text-xs">
                  {/* Quick +/- buttons */}
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => adjustProgress(item.id, -10)}
                      className="px-2 py-1 rounded-lg bg-[#FAF7F2] border border-[#EFE8DF] text-[11px] text-[#5C5651] hover:bg-[#EDE6DD] transition-colors"
                      title="Kurangi 10%"
                    >
                      -10%
                    </button>
                    <button
                      onClick={() => adjustProgress(item.id, 10)}
                      className="px-2 py-1 rounded-lg bg-[#FAF7F2] border border-[#EFE8DF] text-[11px] text-[#5C5651] hover:bg-[#EDE6DD] transition-colors"
                      title="Tambah 10%"
                    >
                      +10%
                    </button>
                    {isFinished ? (
                      <span className="text-[11px] font-medium text-[#7F998C] bg-[#EDF3F0] px-2 py-0.5 rounded-full ml-1 flex items-center gap-1">
                        <CheckCircle2 size={12} />
                        Tercapai
                      </span>
                    ) : (
                      <button
                        onClick={() => adjustProgress(item.id, 100)}
                        className="text-[11px] font-medium text-[#7F998C] hover:underline ml-1"
                      >
                        Tandai Selesai
                      </button>
                    )}
                  </div>

                  {/* Edit & Delete actions */}
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => openEditModal(item)}
                      className="p-1.5 text-[#8A827B] hover:text-[#2C2B2A] rounded-lg transition-colors"
                      aria-label="Edit target"
                    >
                      <Edit3 size={14} />
                    </button>
                    <button
                      onClick={() => deleteTarget(item.id)}
                      className="p-1.5 text-[#B0A79E] hover:text-[#C47366] rounded-lg transition-colors"
                      aria-label="Hapus target"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Target Modal (Add / Edit) */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/35 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-xl relative border border-[#EFE8DF] text-left">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold text-[#2C2B2A]">
                {editingTargetId ? 'Edit Target' : 'Tambah Target Baru'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-[#857E78] hover:bg-[#FAF7F2]"
              >
                <X size={18} />
              </button>
            </div>

            {errorMessage && (
              <div className="mb-3 p-2.5 rounded-xl bg-[#FCECE9] text-xs text-[#C47366]">
                {errorMessage}
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-[#4A4541] mb-1.5">
                  Nama Target
                </label>
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  placeholder="Contoh: Tilawah 2 halaman setiap hari…"
                  className="w-full text-xs text-[#2C2B2A] p-3 rounded-xl bg-[#FAF7F2] border border-[#EFE8DF] focus:outline-hidden focus:border-[#C47366] focus:bg-white transition-all placeholder:text-[#A09890]"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#4A4541] mb-1.5">
                  Kategori
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['personal', 'ibadah', 'productivity'] as TargetCategory[]).map(
                    (cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setCategoryInput(cat)}
                        className={`p-2 text-xs rounded-xl border transition-all text-center ${
                          categoryInput === cat
                            ? 'bg-[#F8EDE9] border-[#E8A598] text-[#C47366] font-medium'
                            : 'bg-[#FAF7F2] border-[#EFE8DF] text-[#6E6862]'
                        }`}
                      >
                        <span className="block text-sm">{categoryLabels[cat].icon}</span>
                        <span className="text-[10px] mt-0.5 block truncate">
                          {cat === 'personal'
                            ? 'Pribadi'
                            : cat === 'ibadah'
                            ? 'Ibadah'
                            : 'Produktivitas'}
                        </span>
                      </button>
                    )
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#4A4541] mb-1.5">
                  Tenggat / Waktu Target
                </label>
                <input
                  type="text"
                  value={deadlineInput}
                  onChange={(e) => setDeadlineInput(e.target.value)}
                  placeholder="Contoh: Akhir Oktober 2026, 2 pekan lagi…"
                  className="w-full text-xs text-[#2C2B2A] p-3 rounded-xl bg-[#FAF7F2] border border-[#EFE8DF] focus:outline-hidden focus:border-[#C47366] focus:bg-white transition-all placeholder:text-[#A09890]"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-medium text-[#4A4541]">
                    Progress Awal
                  </label>
                  <span className="text-xs font-bold text-[#C47366] tabular-nums">
                    {progressInput}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="5"
                  value={progressInput}
                  onChange={(e) => setProgressInput(Number(e.target.value))}
                  className="w-full accent-[#C47366] cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#4A4541] mb-1.5">
                  Catatan Tambahan (opsional)
                </label>
                <input
                  type="text"
                  value={notesInput}
                  onChange={(e) => setNotesInput(e.target.value)}
                  placeholder="Langkah kecil apa yang akan diambil…"
                  className="w-full text-xs text-[#2C2B2A] p-3 rounded-xl bg-[#FAF7F2] border border-[#EFE8DF] focus:outline-hidden focus:border-[#C47366] focus:bg-white transition-all placeholder:text-[#A09890]"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-[#EFE8DF] text-xs font-medium text-[#6E6862] hover:bg-[#FAF7F2]"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#C47366] text-white text-xs font-medium hover:bg-[#B35F52] shadow-xs"
                >
                  Simpan Target
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
