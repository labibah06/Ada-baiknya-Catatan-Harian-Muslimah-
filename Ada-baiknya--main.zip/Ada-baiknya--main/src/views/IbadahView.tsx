import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Check,
  Heart,
  BookOpen,
  Sun,
  Moon,
  Plus,
  Minus,
  Sparkles,
  RotateCcw,
} from 'lucide-react';
import { ShalatTracker } from '../types';

interface PrayerItem {
  key: keyof ShalatTracker;
  label: string;
  waktu: string;
}

const prayers: PrayerItem[] = [
  { key: 'subuh', label: 'Subuh', waktu: 'Fajar · Awal yang berkah' },
  { key: 'dzuhur', label: 'Dzuhur', waktu: 'Tengah hari · Jeda ketenangan' },
  { key: 'ashar', label: 'Ashar', waktu: 'Sore hari · Menjaga ritme' },
  { key: 'maghrib', label: 'Maghrib', waktu: 'Senja · Syukur pergantian hari' },
  { key: 'isya', label: 'Isya', waktu: 'Malam · Penutup hari yang damai' },
];

export const IbadahView: React.FC = () => {
  const {
    shalat,
    toggleShalat,
    tilawah,
    updateTilawahPages,
    updateTilawahGoal,
    dzikir,
    toggleDzikir,
    incrementDzikirCounter,
    resetDzikirCounter,
    kebaikan,
    toggleKebaikan,
    updateKebaikanNote,
    showToast,
  } = useApp();

  const [customPageInput, setCustomPageInput] = useState(tilawah.pagesRead.toString());
  const [kebaikanText, setKebaikanText] = useState(kebaikan.note);

  // Compute shalat progress
  const shalatCompletedCount = Object.values(shalat).filter(Boolean).length;
  const shalatPercent = Math.round((shalatCompletedCount / 5) * 100);

  const handlePageChange = (val: number) => {
    updateTilawahPages(val);
    setCustomPageInput(val.toString());
  };

  const handleKebaikanSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateKebaikanNote(kebaikanText);
    showToast('Catatan kebaikan tersimpan 🌿');
  };

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-300">
      {/* Title & Subtitle */}
      <div className="pt-2 px-1">
        <h2 className="text-2xl font-bold tracking-tight text-[#2C2B2A] flex items-center gap-2">
          <span>Ruang Qur'an & Ibadah</span>
          <span className="text-xl">🤍</span>
        </h2>
        <p className="text-xs text-[#857E78] mt-1">
          Menjaga tilawah dan hubungan dengan Sang Pencipta dalam keheningan dan kelembutan.
        </p>
      </div>

      {/* 1. Card Shalat 5 Waktu */}
      <section className="bg-white rounded-3xl p-5 border border-[#EFE8DF] shadow-[0_2px_12px_rgba(196,115,102,0.06)]">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="w-7 h-7 rounded-full bg-[#F8EDE9] flex items-center justify-center text-[#C47366]">
              <Sparkles size={14} />
            </span>
            <div>
              <h3 className="text-sm font-semibold text-[#2C2B2A]">
                Shalat Wajib
              </h3>
              <p className="text-[11px] text-[#857E78]">
                {shalatCompletedCount} dari 5 waktu tertunaikan
              </p>
            </div>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-[#FAF7F2] text-[#C47366] border border-[#EFE8DF] tabular-nums">
            {shalatPercent}%
          </span>
        </div>

        {/* Shalat Progress Bar */}
        <div className="w-full bg-[#FAF7F2] h-2 rounded-full overflow-hidden mb-4 border border-[#EFE8DF]/60">
          <div
            className="bg-gradient-to-r from-[#E5988B] to-[#C47366] h-full rounded-full transition-all duration-400 ease-out"
            style={{ width: `${shalatPercent}%` }}
          />
        </div>

        <div className="space-y-2">
          {prayers.map((prayer) => {
            const isDone = shalat[prayer.key];
            return (
              <button
                key={prayer.key}
                type="button"
                onClick={() => toggleShalat(prayer.key)}
                className={`w-full flex items-center justify-between p-3 rounded-2xl border transition-all duration-200 min-h-[48px] ${
                  isDone
                    ? 'bg-[#FAF7F2]/80 border-[#E8DDD1]'
                    : 'bg-white border-[#EFE8DF] hover:border-[#E0D3C4]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 transition-all ${
                      isDone
                        ? 'bg-[#C47366] text-white'
                        : 'border-2 border-[#D8CFC5] bg-white hover:border-[#C47366]'
                    }`}
                  >
                    {isDone && <Check size={14} strokeWidth={2.8} />}
                  </div>
                  <div className="text-left">
                    <p
                      className={`text-xs md:text-sm font-medium ${
                        isDone ? 'line-through text-[#99928A]' : 'text-[#2C2B2A]'
                      }`}
                    >
                      {prayer.label}
                    </p>
                    <p className="text-[10px] text-[#918A83]">{prayer.waktu}</p>
                  </div>
                </div>

                <span
                  className={`text-[11px] font-medium px-2 py-0.5 rounded-full ${
                    isDone
                      ? 'text-[#7F998C] bg-[#EDF3F0]'
                      : 'text-[#9C948D] bg-[#FAF7F2]'
                  }`}
                >
                  {isDone ? 'Selesai' : 'Belum'}
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* 2. Card Qur'an / Tilawah */}
      <section className="bg-white rounded-3xl p-5 border border-[#EFE8DF] shadow-[0_2px_12px_rgba(196,115,102,0.06)]">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="w-7 h-7 rounded-full bg-[#EDF3F0] flex items-center justify-center text-[#7F998C]">
              <BookOpen size={14} />
            </span>
            <div>
              <h3 className="text-sm font-semibold text-[#2C2B2A]">
                Tilawah Hari Ini
              </h3>
              <p className="text-[11px] text-[#857E78]">
                Target: {tilawah.dailyGoal} halaman per hari
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-[#7F998C] bg-[#EDF3F0] px-2.5 py-1 rounded-full tabular-nums">
            {tilawah.pagesRead} / {tilawah.dailyGoal} hal
          </span>
        </div>

        {/* Tilawah Counter Controls */}
        <div className="bg-[#FAF7F2] p-4 rounded-2xl border border-[#EFE8DF] flex items-center justify-between mb-3">
          <button
            onClick={() => handlePageChange(Math.max(0, tilawah.pagesRead - 1))}
            className="w-10 h-10 rounded-xl bg-white border border-[#E2D8CC] flex items-center justify-center text-[#4A4541] hover:bg-[#F3ECE4] active:scale-95 transition-all"
            aria-label="Kurangi halaman"
          >
            <Minus size={16} />
          </button>

          <div className="text-center">
            <span className="text-2xl font-bold text-[#2C2B2A] tabular-nums">
              {tilawah.pagesRead}
            </span>
            <span className="text-xs text-[#857E78] block">halaman dibaca</span>
          </div>

          <button
            onClick={() => handlePageChange(tilawah.pagesRead + 1)}
            className="w-10 h-10 rounded-xl bg-[#7F998C] text-white flex items-center justify-center hover:bg-[#6E887B] active:scale-95 transition-all shadow-xs"
            aria-label="Tambah halaman"
          >
            <Plus size={16} />
          </button>
        </div>

        {/* Quick Page Presets */}
        <div className="flex items-center gap-1.5 justify-center mb-3">
          <button
            onClick={() => handlePageChange(tilawah.pagesRead + 2)}
            className="text-[11px] font-medium px-2.5 py-1 rounded-lg bg-[#FAF7F2] hover:bg-[#EFE8DF] text-[#5C5651] transition-colors"
          >
            +2 Halaman
          </button>
          <button
            onClick={() => handlePageChange(tilawah.pagesRead + 5)}
            className="text-[11px] font-medium px-2.5 py-1 rounded-lg bg-[#FAF7F2] hover:bg-[#EFE8DF] text-[#5C5651] transition-colors"
          >
            +5 Halaman
          </button>
          <button
            onClick={() => handlePageChange(0)}
            className="text-[11px] font-medium px-2.5 py-1 rounded-lg bg-[#FAF7F2] hover:bg-[#FCECE9] text-[#9A8F87] transition-colors"
          >
            Reset
          </button>
        </div>

        {tilawah.pagesRead >= tilawah.dailyGoal && (
          <div className="p-2.5 bg-[#EDF3F0] rounded-xl border border-[#D3E3DA] text-xs text-[#4E7060] flex items-center gap-2">
            <span>🌸</span>
            <span>Alhamdulillah, target tilawah harianmu sudah tercapai!</span>
          </div>
        )}
      </section>

      {/* 3. Card Dzikir Pagi & Petang */}
      <section className="bg-white rounded-3xl p-5 border border-[#EFE8DF] shadow-[0_2px_12px_rgba(196,115,102,0.06)]">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-semibold text-[#2C2B2A]">
              Dzikir Pagi & Petang
            </h3>
            <p className="text-[11px] text-[#857E78]">
              Menenangkan hati dengan mengingat-Nya di setiap waktu
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {/* Dzikir Pagi */}
          <div
            className={`p-3.5 rounded-2xl border transition-all ${
              dzikir.pagi
                ? 'bg-[#FAF7F2]/90 border-[#E5DDD1]'
                : 'bg-white border-[#EFE8DF]'
            }`}
          >
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={() => toggleDzikir('pagi')}
                className="flex items-center gap-3 text-left"
              >
                <div
                  className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 transition-all ${
                    dzikir.pagi
                      ? 'bg-[#C47366] text-white'
                      : 'border-2 border-[#D8CFC5] bg-white'
                  }`}
                >
                  {dzikir.pagi && <Check size={14} strokeWidth={2.8} />}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <Sun size={14} className="text-[#E5988B]" />
                    <span
                      className={`text-xs md:text-sm font-medium ${
                        dzikir.pagi ? 'line-through text-[#99928A]' : 'text-[#2C2B2A]'
                      }`}
                    >
                      Dzikir Pagi
                    </span>
                  </div>
                  <p className="text-[10px] text-[#8C847E]">
                    Setelah Subuh hingga menjelang Dhuhur
                  </p>
                </div>
              </button>

              {/* Mini Tasbih Counter */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => incrementDzikirCounter('pagi')}
                  className="px-2.5 py-1 text-xs font-semibold rounded-xl bg-[#F8EDE9] text-[#C47366] active:scale-95 transition-all tabular-nums"
                  title="Klik untuk menghitung tasbih"
                >
                  {dzikir.counterPagi}x
                </button>
                {dzikir.counterPagi > 0 && (
                  <button
                    type="button"
                    onClick={() => resetDzikirCounter('pagi')}
                    className="p-1 text-[#A39990] hover:text-[#C47366]"
                    title="Reset hitungan"
                  >
                    <RotateCcw size={12} />
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Dzikir Petang */}
          <div
            className={`p-3.5 rounded-2xl border transition-all ${
              dzikir.petang
                ? 'bg-[#FAF7F2]/90 border-[#E5DDD1]'
                : 'bg-white border-[#EFE8DF]'
            }`}
          >
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={() => toggleDzikir('petang')}
                className="flex items-center gap-3 text-left"
              >
                <div
                  className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 transition-all ${
                    dzikir.petang
                      ? 'bg-[#C47366] text-white'
                      : 'border-2 border-[#D8CFC5] bg-white'
                  }`}
                >
                  {dzikir.petang && <Check size={14} strokeWidth={2.8} />}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <Moon size={14} className="text-[#7F998C]" />
                    <span
                      className={`text-xs md:text-sm font-medium ${
                        dzikir.petang ? 'line-through text-[#99928A]' : 'text-[#2C2B2A]'
                      }`}
                    >
                      Dzikir Petang
                    </span>
                  </div>
                  <p className="text-[10px] text-[#8C847E]">
                    Setelah Ashar hingga menjelang Isya
                  </p>
                </div>
              </button>

              {/* Mini Tasbih Counter */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => incrementDzikirCounter('petang')}
                  className="px-2.5 py-1 text-xs font-semibold rounded-xl bg-[#EDF3F0] text-[#7F998C] active:scale-95 transition-all tabular-nums"
                  title="Klik untuk menghitung tasbih"
                >
                  {dzikir.counterPetang}x
                </button>
                {dzikir.counterPetang > 0 && (
                  <button
                    type="button"
                    onClick={() => resetDzikirCounter('petang')}
                    className="p-1 text-[#A39990] hover:text-[#7F998C]"
                    title="Reset hitungan"
                  >
                    <RotateCcw size={12} />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Card Kebaikan Hari Ini */}
      <section className="bg-white rounded-3xl p-5 border border-[#EFE8DF] shadow-[0_2px_12px_rgba(196,115,102,0.06)]">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="text-base">🌱</span>
            <h3 className="text-sm font-semibold text-[#2C2B2A]">
              Kebaikan Hari Ini
            </h3>
          </div>
        </div>

        <button
          type="button"
          onClick={() => toggleKebaikan(!kebaikan.done)}
          className={`w-full flex items-center gap-3 p-3 rounded-2xl border transition-all mb-3 ${
            kebaikan.done
              ? 'bg-[#EDF3F0]/60 border-[#D2E4DA]'
              : 'bg-[#FAF7F2] border-[#EFE8DF]'
          }`}
        >
          <div
            className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 transition-all ${
              kebaikan.done
                ? 'bg-[#7F998C] text-white'
                : 'border-2 border-[#D8CFC5] bg-white'
            }`}
          >
            {kebaikan.done && <Check size={14} strokeWidth={2.8} />}
          </div>
          <span
            className={`text-xs md:text-sm font-medium text-left ${
              kebaikan.done ? 'text-[#3E5C4E]' : 'text-[#4A4541]'
            }`}
          >
            Sudah melakukan satu kebaikan hari ini?
          </span>
        </button>

        <form onSubmit={handleKebaikanSave} className="space-y-2.5">
          <input
            type="text"
            value={kebaikanText}
            onChange={(e) => setKebaikanText(e.target.value)}
            placeholder="Contoh: Menyapa ramah, mendoakan sahabat, sedekah…"
            className="w-full text-xs text-[#2C2B2A] p-3 rounded-xl bg-[#FAF7F2] border border-[#EFE8DF] focus:outline-hidden focus:border-[#7F998C] focus:bg-white transition-all placeholder:text-[#A09890]"
          />
          <div className="flex justify-end">
            <button
              type="submit"
              className="px-3.5 py-1.5 rounded-lg bg-[#FAF7F2] border border-[#EFE8DF] hover:border-[#7F998C] text-xs font-medium text-[#4A4541] transition-all"
            >
              Simpan Catatan
            </button>
          </div>
        </form>
      </section>

      {/* Gentle Non-judgmental Footnote */}
      <div className="p-4 rounded-2xl bg-[#FAF7F2] border border-[#EFE8DF] text-[11px] text-[#7A746E] leading-relaxed text-center">
        🌿 <em>“Amalan yang paling dicintai adalah yang rutin dilakukan meskipun sedikit.”</em>
        <p className="mt-1 text-[#9E968E]">
          Aplikasi ini adalah pengingat pribadi yang menenteramkan, bukan penentu kebaikan seseorang.
        </p>
      </div>
    </div>
  );
};
